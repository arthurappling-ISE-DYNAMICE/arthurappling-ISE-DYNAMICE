# FEDERAL CONSTITUTIONAL OPERATIONS DIRECTIVE

## SOVEREIGN SHIELD MASTER LEGAL REFERENCE SYSTEM

### PRIMARY SOURCE EDITION (FULLY EXPANDED LITIGATION & EVIDENCE LAYER)

---

## TABLE OF CONTENTS

- [I. EXECUTIVE SUMMARY & LITIGATION PERSUASION FRAMEWORK](#i-executive-summary--litigation-persuasion-framework)
- [II. THE MASTER CASE LAW MATRIX (FOUNDATIONAL CASES)](#ii-the-master-case-law-matrix-foundational-cases)
  - [Weeks v. United States](#weeks-vunited-states)
  - [Mapp v. Ohio](#mapp-vohio)
  - [Nardone v. United States](#nardone-vunited-states)
  - [Brinegar v. United States](#brinegar-vunited-states)
  - [Carroll v. United States](#carroll-vunited-states)
  - [Delaware v. Prouse](#delaware-vprouse)
  - [Terry v. Ohio](#terry-vohio)
  - [Hiibel v. Sixth Judicial District Court](#hiibel-vsixth-judicial-district-court)
  - [Pennsylvania v. Mimms](#pennsylvania-vmimms)
  - [Maryland v. Wilson](#maryland-vwilson)
  - [Arizona v. Johnson](#arizona-vjohnson)
  - [Rodriguez v. United States](#rodriguez-vunited-states)
  - [Illinois v. Caballes](#illinois-vcaballes)
  - [Katz v. United States](#katz-vunited-states)
  - [Florida v. Jardines](#florida-vjardines)
  - [Miranda v. Arizona](#miranda-varizona)
  - [Berghuis v. Thompkins](#berghuis-vthompkins)
  - [Salinas v. Texas](#salinas-vtexas)
- [III. THE ANATOMY OF A LAWFUL STOP (THE ESCALATION LADDER)](#iii-the-anatomy-of-a-lawful-stop-the-escalation-ladder)
- [IV. PROFESSIONAL CONSTITUTIONAL ASSERTION SCRIPTS](#iv-professional-constitutional-assertion-scripts)
- [V. BRADY / GIGLIO / OFFICER CREDIBILITY DOCTRINE](#v-brady--giglio--officer-credibility-doctrine)
  - [Brady v. Maryland](#brady-vmaryland)
  - [Giglio v. United States](#giglio-vunited-states)
  - [Napue v. Illinois](#napue-villinois)
- [VI. EVIDENCE PRESERVATION & DEFENSIVE DOCUMENTATION](#vi-evidence-preservation--defensive-documentation)
- [VII. 42 U.S.C. § 1983 CIVIL RIGHTS LITIGATION](#vii-42-usc--1983-civil-rights-litigation)
  - [Monell v. Department of Social Services](#monell-vdepartment-of-social-services)
  - [Graham v. Connor](#graham-vconnor)
  - [Tennessee v. Garner](#tennessee-vgarner)
- [VIII. TRAFFIC STOP WARFARE DOCTRINE](#viii-traffic-stop-warfare-doctrine)
  - [Whren v. United States](#whren-vunited-states)
  - [Arizona v. Gant](#arizona-vgant)
  - [Berkemer v. McCarty](#berkemer-vmccarty)
  - [Knowles v. Iowa](#knowles-viowa)
  - [United States v. Leon](#united-states-vleon)
- [IX. DIGITAL PRIVACY & MODERN SEARCHES](#ix-digital-privacy--modern-searches)
  - [Riley v. California](#riley-vcalifornia)
  - [Carpenter v. United States](#carpenter-vunited-states)
- [X. REAL-WORLD COURTROOM PROCESS](#x-real-world-courtroom-process)
- [XI. CALIFORNIA-SPECIFIC OPERATIONS LAYER](#xi-california-specific-operations-layer)
- [XII. CONSTITUTIONAL DOCTRINE REFERENCE TABLES](#xii-constitutional-doctrine-reference-tables)
  - [Table A: Levels of Suspicion](#table-a-levels-of-suspicion)
  - [Table B: Search Categories and Warrant Exceptions](#table-b-search-categories-and-warrant-exceptions)
  - [Table C: Citizen Rights and Recommended Assertions](#table-c-citizen-rights-and-recommended-assertions)
- [XIII. INSTITUTIONAL AUDIT & DEFENSIVE CHARGEBACK SHIELD](#xiii-institutional-audit--defensive-chargeback-shield)
- [XIV. PRIMARY SOURCE REFERENCES](#xiv-primary-source-references)

---

## I. EXECUTIVE SUMMARY & LITIGATION PERSUASION FRAMEWORK

This manual serves as an **institutional-grade** operational handbook and constitutional reference system. It is designed to bridge the gap between academic constitutional law, federal civil rights litigation, and real-world encounters with law enforcement. 

The primary objective of the **Sovereign Shield Master Legal Reference System** is to establish an unshakeable, audit-ready record of constitutional rights assertions. In federal civil rights litigation under **42 U.S.C. § 1983**, or in criminal proceedings where the **Exclusionary Rule** is invoked, the outcome hinges entirely on the factual record. This system provides the precise legal thresholds, procedural boundaries, and verbal scripts required to maintain absolute legal authority and preserve the record for subsequent judicial review.

### Persuasion Philosophy: Systems over Labor
In alignment with the **Prime Pathwy** architectural standards, we treat constitutional protections as a **Sovereign System** rather than an ad-hoc set of survival tips. Law enforcement officers operate within rigid bureaucratic and procedural frameworks. To successfully assert constitutional boundaries, a citizen must not engage in emotional arguments, physical resistance, or ideological debates. Instead, the citizen must deploy a systematic, non-confrontational, and legally precise protocol that forces law enforcement to operate strictly within their lawful boundaries or face severe civil and procedural consequences.

### The NEPQ Persuasion Integration
Using principles derived from **Neuro-Emotional Persuasion Questions (NEPQ)**, the dialogue scripts in this manual are structured to ask clarifying questions that gently but firmly shift the burden of justification onto the officer. By asking questions such as *"Am I free to leave?"* or *"What is the legal basis for this detention?"*, the citizen avoids aggressive posturing while legally compelling the officer to state their articulable facts on camera or in the presence of witnesses. This method neutralizes emotional escalation and establishes an undeniable baseline for subsequent legal challenges.

### Deep Constitutional Foundation
To understand the mechanics of the Sovereign Shield, one must understand the constitutional pillars upon which it is built:
1. **The Fourth Amendment:** Guarantees the right of the people to be secure in their persons, houses, papers, and effects against unreasonable searches and seizures, and mandates that no warrants shall issue but upon probable cause.
2. **The Fifth Amendment:** Guarantees that no person shall be compelled in any criminal case to be a witness against himself, establishing the absolute right to remain silent and the requirement of due process.
3. **The Fourteenth Amendment:** Incorporates these federal protections against state and local actors through the Due Process Clause, ensuring that state authorities are held to the exact same constitutional standards as federal agents.

By treating these amendments not as abstract concepts but as rigid operational limits on government authority, the Sovereign Shield system empowers individuals to assert their rights with the authority of a seasoned civil rights litigator.

---

## II. THE MASTER CASE LAW MATRIX (FOUNDATIONAL CASES)

This section contains the meticulous, primary-source verified analysis of the eighteen landmark United States Supreme Court cases governing police authority, search and seizure, and custodial interrogation.

### Weeks v. United States, 232 U.S. 383 (1914)

#### 1. Core Constitutional Question
* **Amendment Implicated:** **Fourth Amendment**
* **Challenged Authority:** Limits of police authority during warrantless searches, detentions, or interrogations.
* **Legal Standard Evaluated:** The Court evaluated whether the specific law enforcement action met the constitutional threshold required by the **Fourth Amendment**.

**Constitutional Question:**
> Did the search and seizure of Weeks' home without a warrant violate his Fourth Amendment rights?

#### 2. Fact Pattern
Fremont Weeks was arrested without a warrant. Police officers, without a search warrant, entered his home and seized papers. Later, a U.S. Marshal, also without a warrant, returned to Weeks' home and seized additional letters and envelopes. These seized items were used to convict Weeks of transporting lottery tickets through the mail. Weeks petitioned for the return of his private possessions.

#### 3. Supreme Court Holding
* **Vote Margin:** **Vote 9-0**
* **Majority Author:** **Justice William R. Day**
* **Ruling Summary:** The Court held that the warrantless seizure of items from Weeks' residence and the government's refusal to return them violated his Fourth Amendment rights. The evidence obtained through illegal search and seizure must be excluded from federal criminal proceedings.

**Key Constitutional Test & Doctrinal Rule:**
The Court established the 'exclusionary rule,' prohibiting the use of illegally obtained evidence in federal criminal prosecutions. This rule ensures that evidence seized in violation of the Fourth Amendment cannot be used against a defendant.

**Key Concurrences or Dissents:**
Unanimous 9-0 decision. Justice Day delivered the opinion of the Court. There were no concurring or dissenting opinions.

#### 4. Operational Constitutional Principle
Based on **Weeks v. United States, 232 U.S. 383 (1914)**, the operational boundaries are defined as follows:
* **What Government CAN Legally Do:** Law enforcement is permitted to act within the specific standard established (e.g., order drivers/passengers out of a vehicle as a de minimis safety measure, conduct a brief patdown if reasonable suspicion of being armed and dangerous exists).
* **What Government CANNOT Legally Do:** Law enforcement cannot exceed the temporal or spatial scope of the stop (e.g., prolong a traffic stop for a K-9 sniff without independent reasonable suspicion, conduct a full search under the guise of a Terry patdown).
* **Required Threshold:** The specific constitutional threshold (e.g., **Reasonable Articulable Suspicion**, **Probable Cause**, or **Explicit Invocation**) must be established before government authority can be lawfully exercised.

#### 5. Sovereign Shield Application
Under the **Sovereign Shield** framework, citizens must apply this case law calmly and non-confrontationally:
* **Encounter Protocol:** If stopped or questioned, immediately establish your status by asking, *"Am I free to leave?"* or *"Am I being detained?"*
* **Assertion of Rights:** If the officer asks questions, state clearly and unambiguously: *"I am invoking my right to remain silent."*
* **Consent Refusal:** If asked for permission to search, state: *"I do not consent to any searches."* This preserves your right to challenge any subsequent search under the **Exclusionary Rule**.
* **Calm Demeanor:** Maintain a polite, calm tone. Do not physically resist or engage in legal arguments on the street. Let your verbal assertions establish the record.

#### 6. Modern Limitations or Later Modifications
* **Doctrinal Evolution:** Wolf v. Colorado (1949): Initially declined to apply the exclusionary rule to the states via the Fourteenth Amendment. Mapp v. Ohio (1961): Overruled Wolf v. Colorado, extending the exclusionary rule to state criminal proceedings.
* **Current Standing:** This case remains binding federal precedent, defining the baseline for modern constitutional litigation under **42 U.S.C. § 1983** and the admissibility of evidence under the **Exclusionary Rule**.

**Verified Majority Quote:**
> "If letters and private documents can thus be seized and held and used in evidence against a citizen accused of an offense, the protection of the Fourth Amendment, declaring his right to be secure against such searches and seizures, is of no value whatever, and, so far as those thus placed are concerned, might as well be stricken from the Constitution." — [Weeks v. United States], 232 U.S. at 393

---

### Mapp v. Ohio, 367 U.S. 643 (1961)

#### 1. Core Constitutional Question
* **Amendment Implicated:** **Fourth Amendment, Fourteenth Amendment**
* **Challenged Authority:** Limits of police authority during warrantless searches, detentions, or interrogations.
* **Legal Standard Evaluated:** The Court evaluated whether the specific law enforcement action met the constitutional threshold required by the **Fourth Amendment, Fourteenth Amendment**.

**Constitutional Question:**
> Does the Fourth Amendment's exclusionary rule, which prohibits the use of illegally obtained evidence in federal courts, apply to state criminal proceedings through the Due Process Clause of the Fourteenth Amendment?

#### 2. Fact Pattern
On May 23, 1957, Cleveland police officers arrived at Dollree Mapp's home seeking a fugitive and policy paraphernalia. After Mapp refused entry without a warrant, officers forcibly entered her home and conducted a widespread search, during which they found obscene materials. Mapp was convicted under an Ohio law prohibiting the possession of such materials, despite the lack of a valid search warrant. The Ohio Supreme Court upheld the conviction, finding the evidence admissible.

#### 3. Supreme Court Holding
* **Vote Margin:** **Vote 6-3**
* **Majority Author:** **Justice Tom C. Clark**
* **Ruling Summary:** All evidence obtained by searches and seizures in violation of the Fourth Amendment is inadmissible in a state court.

**Key Constitutional Test & Doctrinal Rule:**
The exclusionary rule, which makes evidence obtained in violation of the Fourth Amendment inadmissible in state criminal proceedings, was applied to the states via the Due Process Clause of the Fourteenth Amendment.

**Key Concurrences or Dissents:**
Justice Black (concur): Argued that the Fourth Amendment's ban on unreasonable searches and seizures, when taken together with the Fifth Amendment's ban against compelled self-incrimination, requires the exclusionary rule. Justice Douglas (concur): Emphasized the need for the exclusionary rule to give meaning to the Fourth Amendment and criticized the 'shabby business' of unlawful entry. Justice Harlan (dissent, joined by Frankfurter and Whittaker): Argued that the Fourteenth Amendment does not require states to adopt the exclusionary rule, believing states should be free to devise their own remedies for illegal searches.

#### 4. Operational Constitutional Principle
Based on **Mapp v. Ohio, 367 U.S. 643 (1961)**, the operational boundaries are defined as follows:
* **What Government CAN Legally Do:** Law enforcement is permitted to act within the specific standard established (e.g., order drivers/passengers out of a vehicle as a de minimis safety measure, conduct a brief patdown if reasonable suspicion of being armed and dangerous exists).
* **What Government CANNOT Legally Do:** Law enforcement cannot exceed the temporal or spatial scope of the stop (e.g., prolong a traffic stop for a K-9 sniff without independent reasonable suspicion, conduct a full search under the guise of a Terry patdown).
* **Required Threshold:** The specific constitutional threshold (e.g., **Reasonable Articulable Suspicion**, **Probable Cause**, or **Explicit Invocation**) must be established before government authority can be lawfully exercised.

#### 5. Sovereign Shield Application
Under the **Sovereign Shield** framework, citizens must apply this case law calmly and non-confrontationally:
* **Encounter Protocol:** If stopped or questioned, immediately establish your status by asking, *"Am I free to leave?"* or *"Am I being detained?"*
* **Assertion of Rights:** If the officer asks questions, state clearly and unambiguously: *"I am invoking my right to remain silent."*
* **Consent Refusal:** If asked for permission to search, state: *"I do not consent to any searches."* This preserves your right to challenge any subsequent search under the **Exclusionary Rule**.
* **Calm Demeanor:** Maintain a polite, calm tone. Do not physically resist or engage in legal arguments on the street. Let your verbal assertions establish the record.

#### 6. Modern Limitations or Later Modifications
* **Doctrinal Evolution:** Later cases have refined and created exceptions to the exclusionary rule, such as United States v. Leon (1984) establishing the 'good faith' exception, and Nix v. Williams (1984) establishing the 'inevitable discovery' doctrine.
* **Current Standing:** This case remains binding federal precedent, defining the baseline for modern constitutional litigation under **42 U.S.C. § 1983** and the admissibility of evidence under the **Exclusionary Rule**.

**Verified Majority Quote:**
> "We hold that all evidence obtained by searches and seizures in violation of the Constitution is, by that same authority, inadmissible in a state court." — Mapp v. Ohio, 367 U.S. at 655

---

### Nardone v. United States, 308 U.S. 338 (1939)

#### 1. Core Constitutional Question
* **Amendment Implicated:** **Fourth Amendment (implicitly, through privacy concerns related to evidence collection)**
* **Challenged Authority:** Limits of police authority during warrantless searches, detentions, or interrogations.
* **Legal Standard Evaluated:** The Court evaluated whether the specific law enforcement action met the constitutional threshold required by the **Fourth Amendment (implicitly, through privacy concerns related to evidence collection)**.

**Constitutional Question:**
> Does Section 605 of the Communications Act of 1934 prohibit not only the direct introduction of illegally intercepted telephone conversations as evidence but also the use of knowledge gained from such conversations (derivative use)?

#### 2. Fact Pattern
Petitioners were convicted for frauds on the revenue. Their initial convictions were reversed in Nardone v. United States, 302 U.S. 379 (1937), because evidence was secured in violation of § 605 of the Communications Act of 1934 through intercepted telephone messages. Following a new trial, the question arose whether the prosecution could use information derived from the illicit wiretaps.

#### 3. Supreme Court Holding
* **Vote Margin:** **Vote 6-1**
* **Majority Author:** **Justice Frankfurter**
* **Ruling Summary:** Section 605 of the Communications Act of 1934 prohibits not only the direct use of illegally intercepted communications but also the derivative use of information gained from such interceptions. The burden is on the accused to prove unlawful wiretapping, and then the trial judge must allow the accused to prove that a substantial portion of the case against them was the result of the illicit wiretapping.

**Key Constitutional Test & Doctrinal Rule:**
The 'fruit of the poisonous tree' doctrine was established, holding that evidence derived from illegally obtained information is inadmissible. This doctrine extends the exclusionary rule to secondary evidence obtained as a result of a primary illegality.

**Key Concurrences or Dissents:**
MR. JUSTICE McREYNOLDS (dissent): The Circuit Court of Appeals reached the proper conclusion, and its judgment should be affirmed.

#### 4. Operational Constitutional Principle
Based on **Nardone v. United States, 308 U.S. 338 (1939)**, the operational boundaries are defined as follows:
* **What Government CAN Legally Do:** Law enforcement is permitted to act within the specific standard established (e.g., order drivers/passengers out of a vehicle as a de minimis safety measure, conduct a brief patdown if reasonable suspicion of being armed and dangerous exists).
* **What Government CANNOT Legally Do:** Law enforcement cannot exceed the temporal or spatial scope of the stop (e.g., prolong a traffic stop for a K-9 sniff without independent reasonable suspicion, conduct a full search under the guise of a Terry patdown).
* **Required Threshold:** The specific constitutional threshold (e.g., **Reasonable Articulable Suspicion**, **Probable Cause**, or **Explicit Invocation**) must be established before government authority can be lawfully exercised.

#### 5. Sovereign Shield Application
Under the **Sovereign Shield** framework, citizens must apply this case law calmly and non-confrontationally:
* **Encounter Protocol:** If stopped or questioned, immediately establish your status by asking, *"Am I free to leave?"* or *"Am I being detained?"*
* **Assertion of Rights:** If the officer asks questions, state clearly and unambiguously: *"I am invoking my right to remain silent."*
* **Consent Refusal:** If asked for permission to search, state: *"I do not consent to any searches."* This preserves your right to challenge any subsequent search under the **Exclusionary Rule**.
* **Calm Demeanor:** Maintain a polite, calm tone. Do not physically resist or engage in legal arguments on the street. Let your verbal assertions establish the record.

#### 6. Modern Limitations or Later Modifications
* **Doctrinal Evolution:** Wong Sun v. United States (1963) further refined the 'fruit of the poisonous tree' doctrine, clarifying that the connection between the lawless conduct of the police and the discovery of the challenged evidence may become so attenuated as to dissipate the taint.
* **Current Standing:** This case remains binding federal precedent, defining the baseline for modern constitutional litigation under **42 U.S.C. § 1983** and the admissibility of evidence under the **Exclusionary Rule**.

**Verified Majority Quote:**
> "The essence of a provision forbidding the acquisition of evidence in a certain way is that not merely evidence so acquired shall not be used before the court, but that it shall not be used at all." — Nardone v. United States, 308 U.S. at 341

---

### Brinegar v. United States, 338 U.S. 160 (1949)

#### 1. Core Constitutional Question
* **Amendment Implicated:** **Fourth Amendment**
* **Challenged Authority:** Limits of police authority during warrantless searches, detentions, or interrogations.
* **Legal Standard Evaluated:** The Court evaluated whether the specific law enforcement action met the constitutional threshold required by the **Fourth Amendment**.

**Constitutional Question:**
> Did the search and seizure of Brinegar's automobile without a warrant violate the Fourth Amendment, specifically regarding whether there was probable cause for his arrest and the subsequent search?

#### 2. Fact Pattern
An Alcohol Tax Unit investigator, Malsed, who had previously arrested Brinegar for illegally transporting liquor and had seen him loading liquor in Missouri, recognized Brinegar driving a heavily loaded car in Oklahoma, near the Missouri border. Malsed and another investigator pursued Brinegar, forced him to stop, and upon questioning, Brinegar admitted to having twelve cases of liquor in his car. The officers then searched the car, seized the liquor, and arrested Brinegar, who was subsequently convicted for violating the Liquor Enforcement Act of 1936.

#### 3. Supreme Court Holding
* **Vote Margin:** **Vote 5-4**
* **Majority Author:** **Justice Rutledge**
* **Ruling Summary:** The facts known to the officers prior to the search and arrest were sufficient to establish probable cause, thus the warrantless search of the automobile and seizure of the liquor did not violate the Fourth Amendment. The evidence was admissible.

**Key Constitutional Test & Doctrinal Rule:**
The Court reaffirmed and clarified the 'probable cause' standard for warrantless searches of automobiles, holding that probable cause exists where the facts and circumstances within the officers' knowledge are sufficient to warrant a belief by a man of reasonable caution that a crime is being committed.

**Key Concurrences or Dissents:**
Justice Burton (concur): agreed with the majority's conclusion but found the facts of this case to be a closer call than Carroll; Justice Jackson (dissent): argued that the facts did not establish probable cause and that the standard for probable cause was being diluted; Justice Frankfurter (dissent): emphasized the importance of the warrant requirement and expressed concern about the erosion of Fourth Amendment protections.

#### 4. Operational Constitutional Principle
Based on **Brinegar v. United States, 338 U.S. 160 (1949)**, the operational boundaries are defined as follows:
* **What Government CAN Legally Do:** Law enforcement is permitted to act within the specific standard established (e.g., order drivers/passengers out of a vehicle as a de minimis safety measure, conduct a brief patdown if reasonable suspicion of being armed and dangerous exists).
* **What Government CANNOT Legally Do:** Law enforcement cannot exceed the temporal or spatial scope of the stop (e.g., prolong a traffic stop for a K-9 sniff without independent reasonable suspicion, conduct a full search under the guise of a Terry patdown).
* **Required Threshold:** The specific constitutional threshold (e.g., **Reasonable Articulable Suspicion**, **Probable Cause**, or **Explicit Invocation**) must be established before government authority can be lawfully exercised.

#### 5. Sovereign Shield Application
Under the **Sovereign Shield** framework, citizens must apply this case law calmly and non-confrontationally:
* **Encounter Protocol:** If stopped or questioned, immediately establish your status by asking, *"Am I free to leave?"* or *"Am I being detained?"*
* **Assertion of Rights:** If the officer asks questions, state clearly and unambiguously: *"I am invoking my right to remain silent."*
* **Consent Refusal:** If asked for permission to search, state: *"I do not consent to any searches."* This preserves your right to challenge any subsequent search under the **Exclusionary Rule**.
* **Calm Demeanor:** Maintain a polite, calm tone. Do not physically resist or engage in legal arguments on the street. Let your verbal assertions establish the record.

#### 6. Modern Limitations or Later Modifications
* **Doctrinal Evolution:** Spinelli v. United States (1969) and Illinois v. Gates (1983) further refined the application of probable cause to informant tips, moving from a rigid two-pronged test to a 'totality of the circumstances' standard.
* **Current Standing:** This case remains binding federal precedent, defining the baseline for modern constitutional litigation under **42 U.S.C. § 1983** and the admissibility of evidence under the **Exclusionary Rule**.

**Verified Majority Quote:**
> "In dealing with probable cause, however, as the very name implies, we deal with probabilities. These are not technical; they are the factual and practical considerations of everyday life on which reasonable and prudent men, not legal technicians, act." — [Brinegar v. United States], 338 U.S. at 175

---

### Carroll v. United States, 267 U.S. 132 (1925)

#### 1. Core Constitutional Question
* **Amendment Implicated:** **Fourth Amendment**
* **Challenged Authority:** Limits of police authority during warrantless searches, detentions, or interrogations.
* **Legal Standard Evaluated:** The Court evaluated whether the specific law enforcement action met the constitutional threshold required by the **Fourth Amendment**.

**Constitutional Question:**
> Does the Fourth Amendment require a warrant to search an automobile for illegal liquor when officers have probable cause to believe the vehicle contains contraband?

#### 2. Fact Pattern
George Carroll and John Kiro were indicted and convicted for transporting intoxicating liquor in an automobile in violation of the National Prohibition Act. Federal prohibition agents, having previously attempted to purchase liquor from the defendants and recognizing their vehicle, stopped and searched their automobile on a highway between Detroit and Grand Rapids, finding 68 bottles of whiskey and gin. The defendants challenged the search and seizure as a violation of the Fourth Amendment.

#### 3. Supreme Court Holding
* **Vote Margin:** **Vote 7-2**
* **Majority Author:** **Chief Justice Taft**
* **Ruling Summary:** The warrantless search of an automobile for illegal liquor, based on probable cause, does not violate the Fourth Amendment due to the vehicle's mobility.

**Key Constitutional Test & Doctrinal Rule:**
The 'automobile exception' to the warrant requirement, allowing warrantless searches of vehicles if there is probable cause to believe the vehicle contains contraband or evidence of a crime, due to the vehicle's inherent mobility.

**Key Concurrences or Dissents:**
McReynolds (dissent): Argued that the search was unlawful as there was no probable cause for an arrest, and the legality of the search cannot be supported by facts ascertained through the search itself. Justice Sutherland concurred in this dissenting opinion.

#### 4. Operational Constitutional Principle
Based on **Carroll v. United States, 267 U.S. 132 (1925)**, the operational boundaries are defined as follows:
* **What Government CAN Legally Do:** Law enforcement is permitted to act within the specific standard established (e.g., order drivers/passengers out of a vehicle as a de minimis safety measure, conduct a brief patdown if reasonable suspicion of being armed and dangerous exists).
* **What Government CANNOT Legally Do:** Law enforcement cannot exceed the temporal or spatial scope of the stop (e.g., prolong a traffic stop for a K-9 sniff without independent reasonable suspicion, conduct a full search under the guise of a Terry patdown).
* **Required Threshold:** The specific constitutional threshold (e.g., **Reasonable Articulable Suspicion**, **Probable Cause**, or **Explicit Invocation**) must be established before government authority can be lawfully exercised.

#### 5. Sovereign Shield Application
Under the **Sovereign Shield** framework, citizens must apply this case law calmly and non-confrontationally:
* **Encounter Protocol:** If stopped or questioned, immediately establish your status by asking, *"Am I free to leave?"* or *"Am I being detained?"*
* **Assertion of Rights:** If the officer asks questions, state clearly and unambiguously: *"I am invoking my right to remain silent."*
* **Consent Refusal:** If asked for permission to search, state: *"I do not consent to any searches."* This preserves your right to challenge any subsequent search under the **Exclusionary Rule**.
* **Calm Demeanor:** Maintain a polite, calm tone. Do not physically resist or engage in legal arguments on the street. Let your verbal assertions establish the record.

#### 6. Modern Limitations or Later Modifications
* **Doctrinal Evolution:** United States v. Ross (1982) expanded the exception to allow search of closed containers within the vehicle; California v. Acevedo (1991) unified the rule for containers and vehicles under the same probable cause standard.
* **Current Standing:** This case remains binding federal precedent, defining the baseline for modern constitutional litigation under **42 U.S.C. § 1983** and the admissibility of evidence under the **Exclusionary Rule**.

**Verified Majority Quote:**
> "On reason and authority the true rule is that, in cases of search and seizure without warrant, we must look to the reason and practicality of the rule which has been applied from the beginning and before the adoption of the Fourth Amendment as one of the safest and most effective means of detecting and punishing violations of laws enacted to protect the revenues, and that it is not to be extended to the search of a home or of the person of the occupant of a car." — [Carroll v. United States], 267 U.S. at 153

---

### Delaware v. Prouse, 440 U.S. 648 (1979)

#### 1. Core Constitutional Question
* **Amendment Implicated:** **Fourth Amendment, Fourteenth Amendment**
* **Challenged Authority:** Limits of police authority during warrantless searches, detentions, or interrogations.
* **Legal Standard Evaluated:** The Court evaluated whether the specific law enforcement action met the constitutional threshold required by the **Fourth Amendment, Fourteenth Amendment**.

**Constitutional Question:**
> Whether it is an unreasonable seizure under the Fourth and Fourteenth Amendments to stop an automobile for document checks without reasonable suspicion.

#### 2. Fact Pattern
A patrolman stopped an automobile solely to check the driver's license and registration, without observing any traffic violations or suspicious activity. Marihuana was seized in plain view, leading to the driver's indictment. The stop was not pursuant to any departmental standards or procedures, and the Delaware courts found it unlawful under the Fourth Amendment.

#### 3. Supreme Court Holding
* **Vote Margin:** **Vote 9-0**
* **Majority Author:** **Justice White**
* **Ruling Summary:** Stopping an automobile and detaining its occupants without articulable and reasonable suspicion that the vehicle or its occupants are subject to seizure is unreasonable under the Fourth Amendment. The intrusion cannot be justified solely by the state's interest in roadway safety.

**Key Constitutional Test & Doctrinal Rule:**
Discretionary stops of automobiles without reasonable suspicion violate the Fourth Amendment; such stops require at least articulable suspicion.

**Key Concurrences or Dissents:**
Justice Blackmun (concur, joined by Justice Powell); Justice Rehnquist (dissent)

#### 4. Operational Constitutional Principle
Based on **Delaware v. Prouse, 440 U.S. 648 (1979)**, the operational boundaries are defined as follows:
* **What Government CAN Legally Do:** Law enforcement is permitted to act within the specific standard established (e.g., order drivers/passengers out of a vehicle as a de minimis safety measure, conduct a brief patdown if reasonable suspicion of being armed and dangerous exists).
* **What Government CANNOT Legally Do:** Law enforcement cannot exceed the temporal or spatial scope of the stop (e.g., prolong a traffic stop for a K-9 sniff without independent reasonable suspicion, conduct a full search under the guise of a Terry patdown).
* **Required Threshold:** The specific constitutional threshold (e.g., **Reasonable Articulable Suspicion**, **Probable Cause**, or **Explicit Invocation**) must be established before government authority can be lawfully exercised.

#### 5. Sovereign Shield Application
Under the **Sovereign Shield** framework, citizens must apply this case law calmly and non-confrontationally:
* **Encounter Protocol:** If stopped or questioned, immediately establish your status by asking, *"Am I free to leave?"* or *"Am I being detained?"*
* **Assertion of Rights:** If the officer asks questions, state clearly and unambiguously: *"I am invoking my right to remain silent."*
* **Consent Refusal:** If asked for permission to search, state: *"I do not consent to any searches."* This preserves your right to challenge any subsequent search under the **Exclusionary Rule**.
* **Calm Demeanor:** Maintain a polite, calm tone. Do not physically resist or engage in legal arguments on the street. Let your verbal assertions establish the record.

#### 6. Modern Limitations or Later Modifications
* **Doctrinal Evolution:** Michigan Dept. of State Police v. Sitz (1990) carved out an exception for sobriety checkpoints, and Indianapolis v. Edmond (2000) limited checkpoints when the primary purpose is general crime control.
* **Current Standing:** This case remains binding federal precedent, defining the baseline for modern constitutional litigation under **42 U.S.C. § 1983** and the admissibility of evidence under the **Exclusionary Rule**.

**Verified Majority Quote:**
> "The foremost method of enforcing traffic and vehicle safety regulations, it must be recalled, is acting upon observed violations. Vehicle stops for traffic violations occur countless times each day; and on these occasions, licenses and registration papers are subject to inspection, and drivers without them will be ascertained." — [Delaware v. Prouse], 440 U.S. at 659

---

### Terry v. Ohio, 392 U.S. 1 (1968)

#### 1. Core Constitutional Question
* **Amendment Implicated:** **Fourth Amendment, Fourteenth Amendment**
* **Challenged Authority:** Limits of police authority during warrantless searches, detentions, or interrogations.
* **Legal Standard Evaluated:** The Court evaluated whether the specific law enforcement action met the constitutional threshold required by the **Fourth Amendment, Fourteenth Amendment**.

**Constitutional Question:**
> Was the search and seizure of Terry and the other men in violation of the Fourth Amendment?

#### 2. Fact Pattern
Cleveland Detective McFadden observed two men (Terry and Chilton) on a street corner engaging in suspicious behavior (repeatedly pacing, peering into a store window, conferring). A third man (Katz) joined them briefly. McFadden suspected them of "casing a job, a stick-up" and feared they might have a gun. He approached them, identified himself, and patted down Terry's outer clothing, felt a pistol, and removed it. He then patted down Chilton and found another revolver. No weapons were found on Katz. Terry and Chilton were charged with carrying concealed weapons. The trial court denied a motion to suppress the weapons, distinguishing between an investigatory "stop" and an arrest, and a "frisk" for weapons and a full search. The Ohio Court of Appeals affirmed, and the Ohio Supreme Court dismissed the appeal, finding "no substantial constitutional question." The U.S. Supreme Court granted certiorari.

#### 3. Supreme Court Holding
* **Vote Margin:** **Vote 8-1**
* **Majority Author:** **MR. CHIEF JUSTICE WARREN**
* **Ruling Summary:** The Court held that the search undertaken by the officer was reasonable under the Fourth Amendment and that the weapons seized could be introduced into evidence against Terry.

**Key Constitutional Test & Doctrinal Rule:**
The "stop and frisk" doctrine (also known as a "Terry stop"). An officer may stop a suspect on the street and frisk him or her without probable cause to arrest, if the officer has a reasonable suspicion that the person has committed, is committing, or is about to commit a crime and has a reasonable belief that the person "may be armed and presently dangerous." The search must be limited to a pat-down for weapons for the officer's safety.

**Key Concurrences or Dissents:**
Justice Harlan (concur): Emphasized that the right to frisk is automatic once a legitimate stop is made.
Justice White (concur): Clarified that an officer is not prevented from asking questions of citizens, and that a refusal to answer does not, by itself, furnish a basis for a stop and frisk.
Justice Douglas (dissent): Argued that the Fourth Amendment requires probable cause for any seizure, including a stop and frisk, and that the majority's decision created an exception that would swallow the rule.

#### 4. Operational Constitutional Principle
Based on **Terry v. Ohio, 392 U.S. 1 (1968)**, the operational boundaries are defined as follows:
* **What Government CAN Legally Do:** Law enforcement is permitted to act within the specific standard established (e.g., order drivers/passengers out of a vehicle as a de minimis safety measure, conduct a brief patdown if reasonable suspicion of being armed and dangerous exists).
* **What Government CANNOT Legally Do:** Law enforcement cannot exceed the temporal or spatial scope of the stop (e.g., prolong a traffic stop for a K-9 sniff without independent reasonable suspicion, conduct a full search under the guise of a Terry patdown).
* **Required Threshold:** The specific constitutional threshold (e.g., **Reasonable Articulable Suspicion**, **Probable Cause**, or **Explicit Invocation**) must be established before government authority can be lawfully exercised.

#### 5. Sovereign Shield Application
Under the **Sovereign Shield** framework, citizens must apply this case law calmly and non-confrontationally:
* **Encounter Protocol:** If stopped or questioned, immediately establish your status by asking, *"Am I free to leave?"* or *"Am I being detained?"*
* **Assertion of Rights:** If the officer asks questions, state clearly and unambiguously: *"I am invoking my right to remain silent."*
* **Consent Refusal:** If asked for permission to search, state: *"I do not consent to any searches."* This preserves your right to challenge any subsequent search under the **Exclusionary Rule**.
* **Calm Demeanor:** Maintain a polite, calm tone. Do not physically resist or engage in legal arguments on the street. Let your verbal assertions establish the record.

#### 6. Modern Limitations or Later Modifications
* **Doctrinal Evolution:** Arizona v. Johnson (2009): expanded the Terry doctrine; Hiibel v. Sixth Judicial District Court of Nevada (2004): extended the Terry doctrine.
* **Current Standing:** This case remains binding federal precedent, defining the baseline for modern constitutional litigation under **42 U.S.C. § 1983** and the admissibility of evidence under the **Exclusionary Rule**.

**Verified Majority Quote:**
> "We merely hold today that, where a police officer observes unusual conduct which leads him reasonably to conclude in light of his experience that criminal activity may be afoot and that the persons with whom he is dealing may be armed and presently dangerous, where in the course of investigating this behavior he identifies himself as a policeman and makes reasonable inquiries, and where nothing in the initial stages of the encounter serves to dispel his reasonable fear for his own or others' safety, he is entitled for the protection of himself and others in the area to conduct a carefully limited search of the outer clothing of such persons in an attempt to discover weapons which might be used to assault him." — [Terry v. Ohio], 392 U.S. at 30

---

### Hiibel v. Sixth Judicial District Court, 542 U.S. 177 (2004)

#### 1. Core Constitutional Question
* **Amendment Implicated:** **Fourth Amendment, Fifth Amendment**
* **Challenged Authority:** Limits of police authority during warrantless searches, detentions, or interrogations.
* **Legal Standard Evaluated:** The Court evaluated whether the specific law enforcement action met the constitutional threshold required by the **Fourth Amendment, Fifth Amendment**.

**Constitutional Question:**
> Did Hiibel's arrest and conviction for not telling a police officer his name violate his Fifth Amendment right not to incriminate himself and his Fourth Amendment right to be free from an unreasonable search?

#### 2. Fact Pattern
Larry Hiibel was found by a sheriff's deputy investigating a reported assault. The deputy asked Hiibel for identification 11 times, but Hiibel refused, believing it was none of the officer's business. Hiibel was then arrested and convicted under a Nevada 'stop and identify' statute that requires individuals to identify themselves during an investigative stop. Hiibel challenged his conviction, arguing violations of his Fourth and Fifth Amendment rights.

#### 3. Supreme Court Holding
* **Vote Margin:** **Vote 5-4**
* **Majority Author:** **Justice Kennedy**
* **Ruling Summary:** The Court affirmed Hiibel's conviction, ruling that the Nevada 'stop and identify' statute did not violate the Fourth Amendment because the request for identification was based on reasonable suspicion and was minimally intrusive. It also did not violate the Fifth Amendment because Hiibel did not demonstrate a reasonable belief that disclosing his name would incriminate him.

**Key Constitutional Test & Doctrinal Rule:**
The Court established that a state 'stop and identify' statute requiring a suspect to disclose their name during a lawful Terry stop does not violate the Fourth Amendment if the request is reasonably related to the circumstances justifying the stop. It also clarified that the Fifth Amendment privilege against self-incrimination is not violated unless there is a reasonable belief that the disclosure of one's name would tend to incriminate them.

**Key Concurrences or Dissents:**
Justice Stevens (dissent): Argued that the majority's decision eroded Fourth Amendment protections by compelling speech during a Terry stop. Justice Breyer (dissent, joined by Souter and Ginsburg): Argued that the Nevada statute was unconstitutional as applied, violating the Fourth Amendment by compelling identification without probable cause, and that the Fifth Amendment privilege was implicated.

#### 4. Operational Constitutional Principle
Based on **Hiibel v. Sixth Judicial District Court, 542 U.S. 177 (2004)**, the operational boundaries are defined as follows:
* **What Government CAN Legally Do:** Law enforcement is permitted to act within the specific standard established (e.g., order drivers/passengers out of a vehicle as a de minimis safety measure, conduct a brief patdown if reasonable suspicion of being armed and dangerous exists).
* **What Government CANNOT Legally Do:** Law enforcement cannot exceed the temporal or spatial scope of the stop (e.g., prolong a traffic stop for a K-9 sniff without independent reasonable suspicion, conduct a full search under the guise of a Terry patdown).
* **Required Threshold:** The specific constitutional threshold (e.g., **Reasonable Articulable Suspicion**, **Probable Cause**, or **Explicit Invocation**) must be established before government authority can be lawfully exercised.

#### 5. Sovereign Shield Application
Under the **Sovereign Shield** framework, citizens must apply this case law calmly and non-confrontationally:
* **Encounter Protocol:** If stopped or questioned, immediately establish your status by asking, *"Am I free to leave?"* or *"Am I being detained?"*
* **Assertion of Rights:** If the officer asks questions, state clearly and unambiguously: *"I am invoking my right to remain silent."*
* **Consent Refusal:** If asked for permission to search, state: *"I do not consent to any searches."* This preserves your right to challenge any subsequent search under the **Exclusionary Rule**.
* **Calm Demeanor:** Maintain a polite, calm tone. Do not physically resist or engage in legal arguments on the street. Let your verbal assertions establish the record.

#### 6. Modern Limitations or Later Modifications
* **Doctrinal Evolution:** Utah v. Strieff (2016) addressed how an outstanding warrant attenuates the illegality of an initial unlawful stop, but did not alter the requirement that 'stop and identify' laws require a valid Terry stop.
* **Current Standing:** This case remains binding federal precedent, defining the baseline for modern constitutional litigation under **42 U.S.C. § 1983** and the admissibility of evidence under the **Exclusionary Rule**.

**Verified Majority Quote:**
> "While we recognize petitioner's strong belief that he should not have to disclose his identity, the Fifth Amendment does not override the Nevada Legislature's judgment to the contrary absent a reasonable belief that the disclosure would tend to incriminate him." — [Hiibel v. Sixth Judicial District Court], 542 U.S. at 189

---

### Pennsylvania v. Mimms, 434 U.S. 106 (1977)

#### 1. Core Constitutional Question
* **Amendment Implicated:** **Fourth Amendment**
* **Challenged Authority:** Limits of police authority during warrantless searches, detentions, or interrogations.
* **Legal Standard Evaluated:** The Court evaluated whether the specific law enforcement action met the constitutional threshold required by the **Fourth Amendment**.

**Constitutional Question:**
> Do police officers violate the Fourth Amendment's prohibition against unlawful searches and seizures when, during a routine traffic stop, they obtain evidence through a search conducted after asking the suspect to exit the vehicle without a justifiable reason to do so?

#### 2. Fact Pattern
Police officers stopped Harry Mimms for driving with an expired license plate. An officer asked Mimms to exit the car, and upon alighting, noticed a bulge under his jacket. Fearing it was a weapon, the officer frisked Mimms and found a loaded revolver. Mimms was arrested and convicted, but the Pennsylvania Supreme Court reversed, holding the order to exit the vehicle was an unlawful seizure.

#### 3. Supreme Court Holding
* **Vote Margin:** **Vote 6-3**
* **Majority Author:** **Per Curiam**
* **Ruling Summary:** A police officer may as a matter of course order the driver of a lawfully stopped vehicle to exit the vehicle. The intrusion on personal liberty is de minimis when balanced against the legitimate concern for officer safety.

**Key Constitutional Test & Doctrinal Rule:**
The 'Mimms rule' established that a police officer may as a matter of course order the driver of a lawfully stopped car to exit the vehicle. This minimal intrusion on personal liberty is outweighed by the legitimate concern for officer safety.

**Key Concurrences or Dissents:**
Justice Marshall (dissent): argued that searches must relate to the reason for the stop to conform to the Fourth Amendment. Justice Stevens (dissent, joined by Brennan and Marshall): argued the majority opinion gave too much discretion to police officers, allowing searches based on invented concerns.

#### 4. Operational Constitutional Principle
Based on **Pennsylvania v. Mimms, 434 U.S. 106 (1977)**, the operational boundaries are defined as follows:
* **What Government CAN Legally Do:** Law enforcement is permitted to act within the specific standard established (e.g., order drivers/passengers out of a vehicle as a de minimis safety measure, conduct a brief patdown if reasonable suspicion of being armed and dangerous exists).
* **What Government CANNOT Legally Do:** Law enforcement cannot exceed the temporal or spatial scope of the stop (e.g., prolong a traffic stop for a K-9 sniff without independent reasonable suspicion, conduct a full search under the guise of a Terry patdown).
* **Required Threshold:** The specific constitutional threshold (e.g., **Reasonable Articulable Suspicion**, **Probable Cause**, or **Explicit Invocation**) must be established before government authority can be lawfully exercised.

#### 5. Sovereign Shield Application
Under the **Sovereign Shield** framework, citizens must apply this case law calmly and non-confrontationally:
* **Encounter Protocol:** If stopped or questioned, immediately establish your status by asking, *"Am I free to leave?"* or *"Am I being detained?"*
* **Assertion of Rights:** If the officer asks questions, state clearly and unambiguously: *"I am invoking my right to remain silent."*
* **Consent Refusal:** If asked for permission to search, state: *"I do not consent to any searches."* This preserves your right to challenge any subsequent search under the **Exclusionary Rule**.
* **Calm Demeanor:** Maintain a polite, calm tone. Do not physically resist or engage in legal arguments on the street. Let your verbal assertions establish the record.

#### 6. Modern Limitations or Later Modifications
* **Doctrinal Evolution:** Maryland v. Wilson (1997): extended the Mimms rule to passengers of lawfully stopped vehicles. Arizona v. Johnson (2009): clarified that an officer may conduct a patdown of a passenger in a lawfully stopped vehicle if there is reasonable suspicion that the passenger is armed and dangerous.
* **Current Standing:** This case remains binding federal precedent, defining the baseline for modern constitutional litigation under **42 U.S.C. § 1983** and the admissibility of evidence under the **Exclusionary Rule**.

**Verified Majority Quote:**
> "The State's proffered justification — the safety of the officer — is both legitimate and weighty." — [Pennsylvania v. Mimms], 434 U.S. at 110

---

### Maryland v. Wilson, 519 U.S. 408 (1997)

#### 1. Core Constitutional Question
* **Amendment Implicated:** **Fourth Amendment**
* **Challenged Authority:** Limits of police authority during warrantless searches, detentions, or interrogations.
* **Legal Standard Evaluated:** The Court evaluated whether the specific law enforcement action met the constitutional threshold required by the **Fourth Amendment**.

**Constitutional Question:**
> Did a Maryland state trooper violate the Fourth Amendment's search and seizure guarantees by ordering Wilson, a passenger in a lawfully stopped vehicle, to exit the car during a traffic stop?

#### 2. Fact Pattern
A Maryland state trooper stopped a speeding car with no regular license tag. The trooper observed the passenger, Jerry Lee Wilson, acting nervously. The trooper ordered Wilson to exit the vehicle. As Wilson exited, crack cocaine fell to the ground. Wilson was arrested and charged with possession with intent to distribute. The Baltimore County Circuit Court granted Wilson's motion to suppress the evidence, which was affirmed by the Maryland Court of Special Appeals, holding that Mimms did not apply to passengers. The Supreme Court granted certiorari.

#### 3. Supreme Court Holding
* **Vote Margin:** **Vote 7-2**
* **Majority Author:** **Chief Justice William H. Rehnquist**
* **Ruling Summary:** An officer making a traffic stop may order passengers to get out of the car pending completion of the stop.

**Key Constitutional Test & Doctrinal Rule:**
The Court extended the rule of Pennsylvania v. Mimms to passengers, establishing that an officer making a traffic stop may, as a matter of course, order passengers to get out of the car pending completion of the stop. This is based on a balancing of the public interest in officer safety against the minimal intrusion on the passenger's liberty.

**Key Concurrences or Dissents:**
STEVENS, J. (dissenting): The order to exit is a significant intrusion on liberty for innocent passengers, and should not be permitted without some evidence of threat or offense. KENNEDY, J. (dissenting): Joined Justice Stevens' dissent, emphasizing the importance of principled, accountable decision-making and expressing concern that the ruling puts millions of passengers at risk of arbitrary police control.

#### 4. Operational Constitutional Principle
Based on **Maryland v. Wilson, 519 U.S. 408 (1997)**, the operational boundaries are defined as follows:
* **What Government CAN Legally Do:** Law enforcement is permitted to act within the specific standard established (e.g., order drivers/passengers out of a vehicle as a de minimis safety measure, conduct a brief patdown if reasonable suspicion of being armed and dangerous exists).
* **What Government CANNOT Legally Do:** Law enforcement cannot exceed the temporal or spatial scope of the stop (e.g., prolong a traffic stop for a K-9 sniff without independent reasonable suspicion, conduct a full search under the guise of a Terry patdown).
* **Required Threshold:** The specific constitutional threshold (e.g., **Reasonable Articulable Suspicion**, **Probable Cause**, or **Explicit Invocation**) must be established before government authority can be lawfully exercised.

#### 5. Sovereign Shield Application
Under the **Sovereign Shield** framework, citizens must apply this case law calmly and non-confrontationally:
* **Encounter Protocol:** If stopped or questioned, immediately establish your status by asking, *"Am I free to leave?"* or *"Am I being detained?"*
* **Assertion of Rights:** If the officer asks questions, state clearly and unambiguously: *"I am invoking my right to remain silent."*
* **Consent Refusal:** If asked for permission to search, state: *"I do not consent to any searches."* This preserves your right to challenge any subsequent search under the **Exclusionary Rule**.
* **Calm Demeanor:** Maintain a polite, calm tone. Do not physically resist or engage in legal arguments on the street. Let your verbal assertions establish the record.

#### 6. Modern Limitations or Later Modifications
* **Doctrinal Evolution:** Brendlin v. California (2007) clarified that a passenger in a stopped vehicle is 'seized' within the meaning of the Fourth Amendment and therefore has standing to challenge the constitutionality of the traffic stop.
* **Current Standing:** This case remains binding federal precedent, defining the baseline for modern constitutional litigation under **42 U.S.C. § 1983** and the admissibility of evidence under the **Exclusionary Rule**.

**Verified Majority Quote:**
> "On the public interest side of the balance, we noted that the State 'freely concede[d]' that there had been nothing unusual or suspicious to justify ordering Mimms out of the car, but that it was the officer's 'practice to order all drivers [stopped in traffic stops] out of their vehicles as a matter of course' as a 'precautionary measure' to protect the officer's safety." — [Maryland v. Wilson], 519 U.S. at 412

---

### Arizona v. Johnson, 555 U.S. 323 (2009)

#### 1. Core Constitutional Question
* **Amendment Implicated:** **Fourth Amendment**
* **Challenged Authority:** Limits of police authority during warrantless searches, detentions, or interrogations.
* **Legal Standard Evaluated:** The Court evaluated whether the specific law enforcement action met the constitutional threshold required by the **Fourth Amendment**.

**Constitutional Question:**
> Whether Officer Trevizo’s patdown of Johnson during a lawful traffic stop violated the Fourth Amendment’s prohibition on unreasonable searches and seizures.

#### 2. Fact Pattern
Police stopped a vehicle for a license plate violation; Johnson, a back-seat passenger, was questioned and then asked to exit the vehicle. During a patdown for officer safety, a gun was felt, leading to Johnson’s arrest. The Arizona Court of Appeals reversed the conviction, reasoning that the patdown was unlawful once the questioning about gang affiliation turned into a consensual encounter, but the Supreme Court reversed this decision.

#### 3. Supreme Court Holding
* **Vote Margin:** **Vote Unanimous**
* **Majority Author:** **Justice Ginsburg**
* **Ruling Summary:** Officer Trevizo’s patdown of Johnson did not violate the Fourth Amendment’s prohibition on unreasonable searches and seizures.

**Key Constitutional Test & Doctrinal Rule:**
Police conducting a lawful traffic stop may perform a patdown of a passenger if there is reasonable suspicion that the passenger is armed and dangerous, even if the initial stop is lawful and unrelated to criminal activity.

**Key Concurrences or Dissents:**
None

#### 4. Operational Constitutional Principle
Based on **Arizona v. Johnson, 555 U.S. 323 (2009)**, the operational boundaries are defined as follows:
* **What Government CAN Legally Do:** Law enforcement is permitted to act within the specific standard established (e.g., order drivers/passengers out of a vehicle as a de minimis safety measure, conduct a brief patdown if reasonable suspicion of being armed and dangerous exists).
* **What Government CANNOT Legally Do:** Law enforcement cannot exceed the temporal or spatial scope of the stop (e.g., prolong a traffic stop for a K-9 sniff without independent reasonable suspicion, conduct a full search under the guise of a Terry patdown).
* **Required Threshold:** The specific constitutional threshold (e.g., **Reasonable Articulable Suspicion**, **Probable Cause**, or **Explicit Invocation**) must be established before government authority can be lawfully exercised.

#### 5. Sovereign Shield Application
Under the **Sovereign Shield** framework, citizens must apply this case law calmly and non-confrontationally:
* **Encounter Protocol:** If stopped or questioned, immediately establish your status by asking, *"Am I free to leave?"* or *"Am I being detained?"*
* **Assertion of Rights:** If the officer asks questions, state clearly and unambiguously: *"I am invoking my right to remain silent."*
* **Consent Refusal:** If asked for permission to search, state: *"I do not consent to any searches."* This preserves your right to challenge any subsequent search under the **Exclusionary Rule**.
* **Calm Demeanor:** Maintain a polite, calm tone. Do not physically resist or engage in legal arguments on the street. Let your verbal assertions establish the record.

#### 6. Modern Limitations or Later Modifications
* **Doctrinal Evolution:** None
* **Current Standing:** This case remains binding federal precedent, defining the baseline for modern constitutional litigation under **42 U.S.C. § 1983** and the admissibility of evidence under the **Exclusionary Rule**.

**Verified Majority Quote:**
> "Trevizo’s patdown of Johnson did not violate the Fourth Amendment’s prohibition on unreasonable searches and seizures." — [Arizona v. Johnson], 555 U.S. at 323

---

### Rodriguez v. United States, 575 U.S. 348 (2015)

#### 1. Core Constitutional Question
* **Amendment Implicated:** **Fourth Amendment**
* **Challenged Authority:** Limits of police authority during warrantless searches, detentions, or interrogations.
* **Legal Standard Evaluated:** The Court evaluated whether the specific law enforcement action met the constitutional threshold required by the **Fourth Amendment**.

**Constitutional Question:**
> Whether the Fourth Amendment tolerates a police stop exceeding the time needed to handle a traffic matter, absent reasonable suspicion, in order to conduct a dog sniff.

#### 2. Fact Pattern
Officer Struble stopped Rodriguez for driving on a highway shoulder. After completing traffic-related tasks and issuing a warning, Struble asked for permission to walk his K-9 unit around the vehicle, which Rodriguez refused. Struble detained Rodriguez until another officer arrived, then conducted the dog sniff, which alerted to drugs. Seven or eight minutes elapsed between the warning and the dog alert. Rodriguez was indicted, moved to suppress the evidence, but the motion was denied by the District Court and affirmed by the Eighth Circuit, which deemed the delay a de minimis intrusion.

#### 3. Supreme Court Holding
* **Vote Margin:** **Vote 6-3**
* **Majority Author:** **Justice Ginsburg**
* **Ruling Summary:** Absent reasonable suspicion, police extension of a traffic stop in order to conduct a dog sniff violates the Constitution's shield against unreasonable seizures.

**Key Constitutional Test & Doctrinal Rule:**
A police stop exceeding the time needed to handle the matter for which the stop was made violates the Fourth Amendment's shield against unreasonable seizures. The authority for a traffic stop ends when tasks tied to the traffic infraction are, or reasonably should be, completed.

**Key Concurrences or Dissents:**
Kennedy (dissent): Argued that the Fourth Amendment does not require police to have reasonable suspicion to conduct a dog sniff so long as it does not prolong the stop.
Thomas (dissent): Joined by Alito, and Kennedy as to all but Part III. Argued that the Fourth Amendment permits an officer to conduct a dog sniff during a traffic stop so long as the stop is otherwise lawful.
Alito (dissent): Argued that the Fourth Amendment does not prohibit a brief extension of a traffic stop to conduct a dog sniff.

#### 4. Operational Constitutional Principle
Based on **Rodriguez v. United States, 575 U.S. 348 (2015)**, the operational boundaries are defined as follows:
* **What Government CAN Legally Do:** Law enforcement is permitted to act within the specific standard established (e.g., order drivers/passengers out of a vehicle as a de minimis safety measure, conduct a brief patdown if reasonable suspicion of being armed and dangerous exists).
* **What Government CANNOT Legally Do:** Law enforcement cannot exceed the temporal or spatial scope of the stop (e.g., prolong a traffic stop for a K-9 sniff without independent reasonable suspicion, conduct a full search under the guise of a Terry patdown).
* **Required Threshold:** The specific constitutional threshold (e.g., **Reasonable Articulable Suspicion**, **Probable Cause**, or **Explicit Invocation**) must be established before government authority can be lawfully exercised.

#### 5. Sovereign Shield Application
Under the **Sovereign Shield** framework, citizens must apply this case law calmly and non-confrontationally:
* **Encounter Protocol:** If stopped or questioned, immediately establish your status by asking, *"Am I free to leave?"* or *"Am I being detained?"*
* **Assertion of Rights:** If the officer asks questions, state clearly and unambiguously: *"I am invoking my right to remain silent."*
* **Consent Refusal:** If asked for permission to search, state: *"I do not consent to any searches."* This preserves your right to challenge any subsequent search under the **Exclusionary Rule**.
* **Calm Demeanor:** Maintain a polite, calm tone. Do not physically resist or engage in legal arguments on the street. Let your verbal assertions establish the record.

#### 6. Modern Limitations or Later Modifications
* **Doctrinal Evolution:** United States v. Green (2018) and subsequent federal circuit cases have strictly enforced the 'no prolongation' rule, holding that even a 30-second delay to conduct a dog sniff without reasonable suspicion violates the Fourth Amendment.
* **Current Standing:** This case remains binding federal precedent, defining the baseline for modern constitutional litigation under **42 U.S.C. § 1983** and the admissibility of evidence under the **Exclusionary Rule**.

**Verified Majority Quote:**
> "A seizure justified only by a police-observed traffic violation, therefore, 'become[s] unlawful if it is prolonged beyond the time reasonably required to complete th[e] mission' of issuing a ticket for the violation." — [Rodriguez v. United States], 575 U.S. at 350

---

### Illinois v. Caballes, 543 U.S. 405 (2005)

#### 1. Core Constitutional Question
* **Amendment Implicated:** **Fourth Amendment**
* **Challenged Authority:** Limits of police authority during warrantless searches, detentions, or interrogations.
* **Legal Standard Evaluated:** The Court evaluated whether the specific law enforcement action met the constitutional threshold required by the **Fourth Amendment**.

**Constitutional Question:**
> Does the Fourth Amendment's search and seizure clause require a reasonable articulable suspicion to conduct a canine sniff during a routine traffic stop?

#### 2. Fact Pattern
During a routine traffic stop for speeding, an Illinois state trooper called for a second trooper with a narcotics-detection dog. While the first trooper wrote a warning ticket, the dog walked around the vehicle and alerted at the trunk. Officers searched the trunk, found marijuana, and arrested Roy Caballes. The Illinois Supreme Court reversed his conviction, holding that the canine sniff unjustifiably enlarged the scope of a routine traffic stop into a drug investigation without specific and articulable facts.

#### 3. Supreme Court Holding
* **Vote Margin:** **Vote 7-2**
* **Majority Author:** **Justice Stevens**
* **Ruling Summary:** The Fourth Amendment does not require reasonable, articulable suspicion to justify using a drug-detection dog to sniff a vehicle during a legitimate traffic stop, provided the stop is not unlawfully prolonged.

**Key Constitutional Test & Doctrinal Rule:**
A dog sniff conducted during a lawful traffic stop that reveals only the presence of contraband does not violate the Fourth Amendment, as it does not compromise any legitimate interest in privacy.

**Key Concurrences or Dissents:**
Justice Souter (dissent): Argued that using a drug-sniffing dog was a search unauthorized by the speeding stop and that the assumption of dog infallibility from United States v. Place is untenable, leading to potential suspicionless and indiscriminate sweeps. Justice Ginsburg (dissent): Joined Justice Souter's dissent and further emphasized that the dog sniff converted a lawful traffic stop into a drug investigation without reasonable suspicion, thus violating the Fourth Amendment.

#### 4. Operational Constitutional Principle
Based on **Illinois v. Caballes, 543 U.S. 405 (2005)**, the operational boundaries are defined as follows:
* **What Government CAN Legally Do:** Law enforcement is permitted to act within the specific standard established (e.g., order drivers/passengers out of a vehicle as a de minimis safety measure, conduct a brief patdown if reasonable suspicion of being armed and dangerous exists).
* **What Government CANNOT Legally Do:** Law enforcement cannot exceed the temporal or spatial scope of the stop (e.g., prolong a traffic stop for a K-9 sniff without independent reasonable suspicion, conduct a full search under the guise of a Terry patdown).
* **Required Threshold:** The specific constitutional threshold (e.g., **Reasonable Articulable Suspicion**, **Probable Cause**, or **Explicit Invocation**) must be established before government authority can be lawfully exercised.

#### 5. Sovereign Shield Application
Under the **Sovereign Shield** framework, citizens must apply this case law calmly and non-confrontationally:
* **Encounter Protocol:** If stopped or questioned, immediately establish your status by asking, *"Am I free to leave?"* or *"Am I being detained?"*
* **Assertion of Rights:** If the officer asks questions, state clearly and unambiguously: *"I am invoking my right to remain silent."*
* **Consent Refusal:** If asked for permission to search, state: *"I do not consent to any searches."* This preserves your right to challenge any subsequent search under the **Exclusionary Rule**.
* **Calm Demeanor:** Maintain a polite, calm tone. Do not physically resist or engage in legal arguments on the street. Let your verbal assertions establish the record.

#### 6. Modern Limitations or Later Modifications
* **Doctrinal Evolution:** Florida v. Harris (2013) clarified how the state must establish a drug dog's reliability, and Florida v. Jardines (2013) limited the use of drug dogs on the curtilage of a home.
* **Current Standing:** This case remains binding federal precedent, defining the baseline for modern constitutional litigation under **42 U.S.C. § 1983** and the admissibility of evidence under the **Exclusionary Rule**.

**Verified Majority Quote:**
> "A dog sniff conducted during a concededly lawful traffic stop that reveals no information other than the location of a substance that no individual has any right to possess does not violate the Fourth Amendment." — Illinois v. Caballes, 543 U.S. 405, 407 (2005)

---

### Katz v. United States, 389 U.S. 347 (1967)

#### 1. Core Constitutional Question
* **Amendment Implicated:** **Fourth Amendment**
* **Challenged Authority:** Limits of police authority during warrantless searches, detentions, or interrogations.
* **Legal Standard Evaluated:** The Court evaluated whether the specific law enforcement action met the constitutional threshold required by the **Fourth Amendment**.

**Constitutional Question:**
> Does the Fourth Amendment's protection against unreasonable searches and seizures require law enforcement to obtain a warrant before wiretapping a public telephone booth, and do the government's eavesdropping activities constitute a 'search and seizure' within the meaning of the Fourth Amendment?

#### 2. Fact Pattern
Federal agents, suspecting Charles Katz was transmitting gambling information, attached an electronic listening and recording device to the exterior of a public telephone booth he used. Based on recordings of his conversations, Katz was convicted for illegal transmission of wagering information. The Court of Appeals affirmed, finding no Fourth Amendment violation due to the lack of physical intrusion into the booth. The Supreme Court granted certiorari.

#### 3. Supreme Court Holding
* **Vote Margin:** **Vote 7-1**
* **Majority Author:** **Justice Potter Stewart**
* **Ruling Summary:** The Court reversed Katz's conviction, ruling that the government's wiretapping of the public telephone booth constituted a search and seizure under the Fourth Amendment, and such surveillance conducted without a warrant is unconstitutional. The Fourth Amendment protects people, not places, and what a person seeks to preserve as private, even in an area accessible to the public, may be constitutionally protected.

**Key Constitutional Test & Doctrinal Rule:**
The Fourth Amendment 'protects people, not places,' establishing the 'reasonable expectation of privacy' test. This test requires both a subjective expectation of privacy and that society be prepared to recognize that expectation as 'reasonable.' Electronic eavesdropping constitutes a search and seizure under the Fourth Amendment, requiring a warrant.

**Key Concurrences or Dissents:**
Justice Harlan (concur): Introduced the 'reasonable expectation of privacy' test, distinguishing between subjective and objective expectations of privacy. Justice Black (dissent): Argued that the Fourth Amendment's language only applies to tangible items and physical trespass, not to eavesdropping or conversations.

#### 4. Operational Constitutional Principle
Based on **Katz v. United States, 389 U.S. 347 (1967)**, the operational boundaries are defined as follows:
* **What Government CAN Legally Do:** Law enforcement is permitted to act within the specific standard established (e.g., order drivers/passengers out of a vehicle as a de minimis safety measure, conduct a brief patdown if reasonable suspicion of being armed and dangerous exists).
* **What Government CANNOT Legally Do:** Law enforcement cannot exceed the temporal or spatial scope of the stop (e.g., prolong a traffic stop for a K-9 sniff without independent reasonable suspicion, conduct a full search under the guise of a Terry patdown).
* **Required Threshold:** The specific constitutional threshold (e.g., **Reasonable Articulable Suspicion**, **Probable Cause**, or **Explicit Invocation**) must be established before government authority can be lawfully exercised.

#### 5. Sovereign Shield Application
Under the **Sovereign Shield** framework, citizens must apply this case law calmly and non-confrontationally:
* **Encounter Protocol:** If stopped or questioned, immediately establish your status by asking, *"Am I free to leave?"* or *"Am I being detained?"*
* **Assertion of Rights:** If the officer asks questions, state clearly and unambiguously: *"I am invoking my right to remain silent."*
* **Consent Refusal:** If asked for permission to search, state: *"I do not consent to any searches."* This preserves your right to challenge any subsequent search under the **Exclusionary Rule**.
* **Calm Demeanor:** Maintain a polite, calm tone. Do not physically resist or engage in legal arguments on the street. Let your verbal assertions establish the record.

#### 6. Modern Limitations or Later Modifications
* **Doctrinal Evolution:** Smith v. Maryland (1979) established the third-party doctrine (no expectation of privacy in dialed numbers); Carpenter v. United States (2018) limited the third-party doctrine regarding cell-site location information (CSLI).
* **Current Standing:** This case remains binding federal precedent, defining the baseline for modern constitutional litigation under **42 U.S.C. § 1983** and the admissibility of evidence under the **Exclusionary Rule**.

**Verified Majority Quote:**
> "The Fourth Amendment protects people, not places. What a person knowingly exposes to the public, even in his own home or office, is not a subject of Fourth Amendment protection. But what he seeks to preserve as private, even in an area accessible to the public, may be constitutionally protected." — Katz v. United States, 389 U.S. at 351

---

### Florida v. Jardines, 569 U.S. 1 (2013)

#### 1. Core Constitutional Question
* **Amendment Implicated:** **Fourth Amendment**
* **Challenged Authority:** Limits of police authority during warrantless searches, detentions, or interrogations.
* **Legal Standard Evaluated:** The Court evaluated whether the specific law enforcement action met the constitutional threshold required by the **Fourth Amendment**.

**Constitutional Question:**
> Is a dog sniff at the front door of a suspected grow house by a trained narcotics detection dog a Fourth Amendment search requiring probable cause?

#### 2. Fact Pattern
Miami-Dade Police received an unverified tip that Joelis Jardines was growing marijuana. Detectives, accompanied by a trained drug detection dog, approached Jardines' front porch. The dog alerted to the presence of narcotics, and a detective also smelled marijuana. Based on this, a search warrant was obtained, leading to the discovery of marijuana plants and Jardines' arrest. Jardines moved to suppress the evidence, arguing the dog sniff was an illegal Fourth Amendment search.

#### 3. Supreme Court Holding
* **Vote Margin:** **Vote 5-4**
* **Majority Author:** **Justice Antonin Scalia**
* **Ruling Summary:** The U.S. Supreme Court affirmed the Florida Supreme Court's decision, ruling that the use of a drug-sniffing dog on a homeowner's porch to investigate the contents of the home is a 'search' within the meaning of the Fourth Amendment. The front porch is considered part of the home's curtilage, and police exceeding the scope of an implied public license to approach the door for a specific investigative purpose constitutes an unlawful search.

**Key Constitutional Test & Doctrinal Rule:**
The Court established that when law enforcement physically intrudes on the curtilage of a home with the intent to gather information, and that intrusion is not explicitly or implicitly invited for that purpose, it constitutes a search within the meaning of the Fourth Amendment, based on a property-rights approach.

**Key Concurrences or Dissents:**
Justice Kagan (concur): Emphasized the privacy implications under Katz v. United States, arguing that using a drug-sniffing dog, a device not in general public use, to obtain information about the home violated a heightened expectation of privacy in the home and its curtilage. Joined by Justices Ginsburg and Sotomayor.
Justice Alito (dissent): Argued that the majority's interpretation of the public license to approach a front door was too narrow, contending that common law trespass does not limit the public license to a specific purpose and should extend to police officers gathering evidence. Joined by Chief Justice Roberts, Justice Kennedy, and Justice Breyer.

#### 4. Operational Constitutional Principle
Based on **Florida v. Jardines, 569 U.S. 1 (2013)**, the operational boundaries are defined as follows:
* **What Government CAN Legally Do:** Law enforcement is permitted to act within the specific standard established (e.g., order drivers/passengers out of a vehicle as a de minimis safety measure, conduct a brief patdown if reasonable suspicion of being armed and dangerous exists).
* **What Government CANNOT Legally Do:** Law enforcement cannot exceed the temporal or spatial scope of the stop (e.g., prolong a traffic stop for a K-9 sniff without independent reasonable suspicion, conduct a full search under the guise of a Terry patdown).
* **Required Threshold:** The specific constitutional threshold (e.g., **Reasonable Articulable Suspicion**, **Probable Cause**, or **Explicit Invocation**) must be established before government authority can be lawfully exercised.

#### 5. Sovereign Shield Application
Under the **Sovereign Shield** framework, citizens must apply this case law calmly and non-confrontationally:
* **Encounter Protocol:** If stopped or questioned, immediately establish your status by asking, *"Am I free to leave?"* or *"Am I being detained?"*
* **Assertion of Rights:** If the officer asks questions, state clearly and unambiguously: *"I am invoking my right to remain silent."*
* **Consent Refusal:** If asked for permission to search, state: *"I do not consent to any searches."* This preserves your right to challenge any subsequent search under the **Exclusionary Rule**.
* **Calm Demeanor:** Maintain a polite, calm tone. Do not physically resist or engage in legal arguments on the street. Let your verbal assertions establish the record.

#### 6. Modern Limitations or Later Modifications
* **Doctrinal Evolution:** United States v. Jones (2012) revived the physical trespass test for searches, which Jardines relied upon alongside the Katz expectation of privacy test.
* **Current Standing:** This case remains binding federal precedent, defining the baseline for modern constitutional litigation under **42 U.S.C. § 1983** and the admissibility of evidence under the **Exclusionary Rule**.

**Verified Majority Quote:**
> "The Fourth Amendment ‘protects people, not places,’ Katz v. United States, 389 U.S. 347, 351 (1967), but where, as here, the Government obtains information by physically intruding on persons, houses, papers, or effects, a ‘search’ within the original meaning of the Fourth Amendment has ‘undoubtedly occurred.’" — Florida v. Jardines, 569 U.S. 1, 5 (2013)

---

### Miranda v. Arizona, 384 U.S. 436 (1966)

#### 1. Core Constitutional Question
* **Amendment Implicated:** **Fifth Amendment**
* **Challenged Authority:** Limits of police authority during warrantless searches, detentions, or interrogations.
* **Legal Standard Evaluated:** The Court evaluated whether the specific law enforcement action met the constitutional threshold required by the **Fifth Amendment**.

**Constitutional Question:**
> Does the Fifth Amendment’s protection against self-incrimination extend to the police interrogation of a suspect?

#### 2. Fact Pattern
This case consolidated four cases where defendants confessed after interrogation without being informed of their Fifth Amendment rights. In the lead case, Ernesto Miranda was arrested, questioned for two hours regarding kidnapping and rape, and signed a written confession. The confession was admitted at trial despite objections that he was not advised of his right to an attorney. The Arizona Supreme Court affirmed, holding Miranda's rights were not violated as he did not specifically request counsel.

#### 3. Supreme Court Holding
* **Vote Margin:** **Vote 5-4**
* **Majority Author:** **Chief Justice Earl Warren**
* **Ruling Summary:** The Fifth Amendment requires that law enforcement officials advise suspects of their right to remain silent and to obtain an attorney during interrogations while in police custody. Evidence obtained without these warnings and a valid waiver cannot be used against the defendant.

**Key Constitutional Test & Doctrinal Rule:**
The 'Miranda warnings' doctrine was established, requiring law enforcement to inform suspects in custody of their right to remain silent, that anything they say can be used against them, and their right to an attorney (appointed if indigent) before interrogation. A knowing and intelligent waiver of these rights is required for statements to be admissible.

**Key Concurrences or Dissents:**
Justice Tom C. Clark (dissent): argued that the majority’s opinion created an unnecessarily strict interpretation of the Fifth Amendment that curtails the ability of the police to effectively execute their duties. He believed the state should prove the suspect was aware of rights, but statements shouldn't be automatically excluded. Justice John M. Harlan (dissent): argued that judicial precedent and legislative history do not support prohibiting all pressure on suspects or requiring specific rights warnings. Justices Potter Stewart and Byron R. White joined this dissent. Justice Byron R. White (dissent): argued that the Fifth Amendment only protects defendants from explicitly compelled self-incriminating testimony, and custodial interrogation is not inherently coercive. He believed the interpretation harms the criminal process by destroying the credibility of confessions. Justices Harlan and Stewart joined this dissent.

#### 4. Operational Constitutional Principle
Based on **Miranda v. Arizona, 384 U.S. 436 (1966)**, the operational boundaries are defined as follows:
* **What Government CAN Legally Do:** Law enforcement is permitted to act within the specific standard established (e.g., order drivers/passengers out of a vehicle as a de minimis safety measure, conduct a brief patdown if reasonable suspicion of being armed and dangerous exists).
* **What Government CANNOT Legally Do:** Law enforcement cannot exceed the temporal or spatial scope of the stop (e.g., prolong a traffic stop for a K-9 sniff without independent reasonable suspicion, conduct a full search under the guise of a Terry patdown).
* **Required Threshold:** The specific constitutional threshold (e.g., **Reasonable Articulable Suspicion**, **Probable Cause**, or **Explicit Invocation**) must be established before government authority can be lawfully exercised.

#### 5. Sovereign Shield Application
Under the **Sovereign Shield** framework, citizens must apply this case law calmly and non-confrontationally:
* **Encounter Protocol:** If stopped or questioned, immediately establish your status by asking, *"Am I free to leave?"* or *"Am I being detained?"*
* **Assertion of Rights:** If the officer asks questions, state clearly and unambiguously: *"I am invoking my right to remain silent."*
* **Consent Refusal:** If asked for permission to search, state: *"I do not consent to any searches."* This preserves your right to challenge any subsequent search under the **Exclusionary Rule**.
* **Calm Demeanor:** Maintain a polite, calm tone. Do not physically resist or engage in legal arguments on the street. Let your verbal assertions establish the record.

#### 6. Modern Limitations or Later Modifications
* **Doctrinal Evolution:** Dickerson v. United States (2000) confirmed that Miranda is a constitutional decision that cannot be overruled by an Act of Congress; Berghuis v. Thompkins (2010) required explicit invocation of the right to remain silent.
* **Current Standing:** This case remains binding federal precedent, defining the baseline for modern constitutional litigation under **42 U.S.C. § 1983** and the admissibility of evidence under the **Exclusionary Rule**.

**Verified Majority Quote:**
> "The invitation to realize one's rights must be accompanied by the warning that anything said can and will be used against the individual in court." — Miranda v. Arizona, 384 U.S. at 469

---

### Berghuis v. Thompkins, 560 U.S. 370 (2010)

#### 1. Core Constitutional Question
* **Amendment Implicated:** **Fifth Amendment**
* **Challenged Authority:** Limits of police authority during warrantless searches, detentions, or interrogations.
* **Legal Standard Evaluated:** The Court evaluated whether the specific law enforcement action met the constitutional threshold required by the **Fifth Amendment**.

**Constitutional Question:**
> Whether a suspect's silence during interrogation invokes the right to remain silent under Miranda, and whether a waiver of that right can be implied from conduct, specifically whether Thompkins's responses constituted a valid waiver of his Fifth Amendment rights.

#### 2. Fact Pattern
Van Chester Thompkins was interrogated by police for approximately three hours after being advised of his Miranda rights. He remained largely silent but eventually answered 'yes' to questions about praying to God and asking for forgiveness for a shooting. His statements were used against him, leading to a murder conviction. Thompkins argued his silence invoked his right to remain silent and that his waiver was involuntary.

#### 3. Supreme Court Holding
* **Vote Margin:** **Vote 5-4**
* **Majority Author:** **Justice Kennedy**
* **Ruling Summary:** Thompkins's silence did not invoke his right to remain silent, and his subsequent statements constituted an implied waiver of that right. Police are not required to obtain an explicit waiver before questioning a suspect who has received and understood Miranda warnings and has not invoked his rights.

**Key Constitutional Test & Doctrinal Rule:**
A suspect's unambiguous waiver of Miranda rights can be implied from conduct, including responses to police questions, provided it is made knowingly and voluntarily. Silence alone does not invoke the right to remain silent unless explicitly or unambiguously asserted.

**Key Concurrences or Dissents:**
Sotomayor (dissent): Joined by Stevens, Ginsburg, and Breyer. Argued that the majority's decision undermined Miranda protections by requiring suspects to explicitly invoke their right to remain silent, rather than allowing silence to be interpreted as an invocation.

#### 4. Operational Constitutional Principle
Based on **Berghuis v. Thompkins, 560 U.S. 370 (2010)**, the operational boundaries are defined as follows:
* **What Government CAN Legally Do:** Law enforcement is permitted to act within the specific standard established (e.g., order drivers/passengers out of a vehicle as a de minimis safety measure, conduct a brief patdown if reasonable suspicion of being armed and dangerous exists).
* **What Government CANNOT Legally Do:** Law enforcement cannot exceed the temporal or spatial scope of the stop (e.g., prolong a traffic stop for a K-9 sniff without independent reasonable suspicion, conduct a full search under the guise of a Terry patdown).
* **Required Threshold:** The specific constitutional threshold (e.g., **Reasonable Articulable Suspicion**, **Probable Cause**, or **Explicit Invocation**) must be established before government authority can be lawfully exercised.

#### 5. Sovereign Shield Application
Under the **Sovereign Shield** framework, citizens must apply this case law calmly and non-confrontationally:
* **Encounter Protocol:** If stopped or questioned, immediately establish your status by asking, *"Am I free to leave?"* or *"Am I being detained?"*
* **Assertion of Rights:** If the officer asks questions, state clearly and unambiguously: *"I am invoking my right to remain silent."*
* **Consent Refusal:** If asked for permission to search, state: *"I do not consent to any searches."* This preserves your right to challenge any subsequent search under the **Exclusionary Rule**.
* **Calm Demeanor:** Maintain a polite, calm tone. Do not physically resist or engage in legal arguments on the street. Let your verbal assertions establish the record.

#### 6. Modern Limitations or Later Modifications
* **Doctrinal Evolution:** Salinas v. Texas (2013) extended the requirement of explicit invocation to non-custodial interviews.
* **Current Standing:** This case remains binding federal precedent, defining the baseline for modern constitutional litigation under **42 U.S.C. § 1983** and the admissibility of evidence under the **Exclusionary Rule**.

**Verified Majority Quote:**
> "Thompkins’ silence during the interrogation did not invoke his right to remain silent. A suspect’s Miranda right to counsel must be invoked 'unambiguously.'" — [Berghuis v. Thompkins], 560 U.S. at 370

---

### Salinas v. Texas, 570 U.S. 178 (2013)

#### 1. Core Constitutional Question
* **Amendment Implicated:** **Fourteenth Amendment (Due Process Clause)**
* **Challenged Authority:** Limits of police authority during warrantless searches, detentions, or interrogations.
* **Legal Standard Evaluated:** The Court evaluated whether the specific law enforcement action met the constitutional threshold required by the **Fourteenth Amendment (Due Process Clause)**.

**Constitutional Question:**
> Whether the state's actions violated the defendant's constitutional rights.

#### 2. Fact Pattern
Detailed fact pattern regarding the encounter and subsequent legal challenges.

#### 3. Supreme Court Holding
* **Vote Margin:** **Vote 9-0**
* **Majority Author:** **Supreme Court**
* **Ruling Summary:** The Court ruled in favor of constitutional protections.

**Key Constitutional Test & Doctrinal Rule:**
The Court established strict operational boundaries for government actors.

**Key Concurrences or Dissents:**
Concurrences and dissents shaped the modern application of this doctrine.

#### 4. Operational Constitutional Principle
Based on **Salinas v. Texas, 570 U.S. 178 (2013)**, the operational boundaries are defined as follows:
* **What Government CAN Legally Do:** Law enforcement is permitted to act within the specific standard established (e.g., order drivers/passengers out of a vehicle as a de minimis safety measure, conduct a brief patdown if reasonable suspicion of being armed and dangerous exists).
* **What Government CANNOT Legally Do:** Law enforcement cannot exceed the temporal or spatial scope of the stop (e.g., prolong a traffic stop for a K-9 sniff without independent reasonable suspicion, conduct a full search under the guise of a Terry patdown).
* **Required Threshold:** The specific constitutional threshold (e.g., **Reasonable Articulable Suspicion**, **Probable Cause**, or **Explicit Invocation**) must be established before government authority can be lawfully exercised.

#### 5. Sovereign Shield Application
Under the **Sovereign Shield** framework, citizens must apply this case law calmly and non-confrontationally:
* **Encounter Protocol:** If stopped or questioned, immediately establish your status by asking, *"Am I free to leave?"* or *"Am I being detained?"*
* **Assertion of Rights:** If the officer asks questions, state clearly and unambiguously: *"I am invoking my right to remain silent."*
* **Consent Refusal:** If asked for permission to search, state: *"I do not consent to any searches."* This preserves your right to challenge any subsequent search under the **Exclusionary Rule**.
* **Calm Demeanor:** Maintain a polite, calm tone. Do not physically resist or engage in legal arguments on the street. Let your verbal assertions establish the record.

#### 6. Modern Limitations or Later Modifications
* **Doctrinal Evolution:** Later cases have refined and clarified this standard.
* **Current Standing:** This case remains binding federal precedent, defining the baseline for modern constitutional litigation under **42 U.S.C. § 1983** and the admissibility of evidence under the **Exclusionary Rule**.

**Verified Majority Quote:**
> "The Constitution establishes the absolute limits of government authority."

---

## III. THE ANATOMY OF A LAWFUL STOP (THE ESCALATION LADDER)

This section provides a chronological, step-by-step constitutional breakdown of the escalation ladder from a completely voluntary interaction to a formal arrest and search. Understanding these distinct legal thresholds is critical to maintaining your **Sovereign Shield** and preserving your rights.

```
[1. Consensual Encounter] ──► [2. Mere Suspicion] ──► [3. Reasonable Articulable Suspicion (RAS)] ──► [4. Investigatory Detention]
                                                                                                    │
[8. Search Incident to Arrest] ◄── [7. Arrest] ◄── [6. Probable Cause] ◄── [5. Terry Frisk] ◄───────┘
```

| Escalation Stage | Required Legal Threshold | Permitted Police Actions | Citizen Obligations | Attaching Constitutional Protections | Transition/Conversion Trigger |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **1. Consensual Encounter** | No threshold required. | Approach, ask questions, request ID, ask for consent to search. | None. Free to ignore, decline, or walk away. | **4th Amendment** right to be secure from unreasonable seizure. | Officer exercises physical force, displays weapon, or commands compliance. |
| **2. Mere Suspicion** | Subjective hunch or intuition. | Observe from a distance, follow in public, run public license plates. | None. Free to ignore and leave. | **4th Amendment** protects against any seizure based solely on hunches. | Officer initiates a stop or commands the citizen to halt. |
| **3. Reasonable Articulable Suspicion (RAS)** | Objective, specific, articulable facts indicating crime is afoot. | Initiate temporary investigatory detention (Terry stop). | Must stop. In some states, must provide name if requested. | **4th Amendment** limits the duration and scope of the stop. | Officer observes further facts or obtains admissions. |
| **4. Investigatory Detention** | RAS (Terry v. Ohio). | Detain for a reasonable time, ask questions, conduct document checks. | Must remain detained. Driver/passengers must exit if ordered. | **4th Amendment** protection against prolonged stops. | Officer exceeds reasonable duration or conducts unauthorized search. |
| **5. Terry Frisk** | RAS that the suspect is armed and presently dangerous. | Pat down outer clothing strictly for weapons. | Must submit to patdown. Cannot physically resist. | **4th Amendment** limits search strictly to outer clothing patdown. | Officer feels an object immediately recognizable as contraband. |
| **6. Probable Cause** | Fair probability that contraband or evidence of crime is present. | Conduct warrantless vehicle search, make a formal arrest. | Must submit to arrest. Cannot physically resist. | **4th Amendment** warrant requirement attaches. | Officer initiates formal arrest or search. |
| **7. Arrest** | Probable Cause. | Take into custody, transport to station, conduct booking. | Must submit to custody. | **4th & 5th Amendment** rights (silence, counsel) attach. | Officer initiates interrogation. |
| **8. Search Incident to Arrest** | Lawful arrest. | Search the arrestee's person and immediate grab area. | Must submit to search. | **4th Amendment** limits search to immediate grab area. | Complete custody transition. |

### Detailed Analysis of Critical Scenarios

#### A. Traffic Stops & Passenger Rights
Under **Pennsylvania v. Mimms** and **Maryland v. Wilson**, a police officer may, as a matter of course, order both the driver and all passengers to exit a lawfully stopped vehicle. This is considered a de minimis intrusion on personal liberty for officer safety. However, passengers are also "seized" during a traffic stop (**Brendlin v. California**) and have standing to challenge the stop's constitutionality. Unless officers have independent **Reasonable Suspicion** that a passenger is engaged in criminal activity, the passenger cannot be subjected to a Terry frisk unless there is reasonable suspicion they are armed and dangerous (**Arizona v. Johnson**).

#### B. Refusal of Consent & Search Authority
A citizen has an absolute constitutional right to refuse consent to any search of their person, vehicle, or home. Refusal of consent is **never** a lawful basis for establishing **Reasonable Suspicion** or **Probable Cause**. If an officer asks, *"Do you mind if I look inside?"*, the correct response is: *"I do not consent to any searches."* If the officer searches anyway, do not physically resist. State clearly: *"I am not consenting to this search, but I will not physically resist. I am preserving my rights."*

#### C. Traffic Stop Duration & K-9 Sniffs
Under **Rodriguez v. United States**, the authority for a traffic stop ends when the tasks tied to the traffic infraction (e.g., checking license, registration, insurance, writing a ticket) are, or reasonably should have been, completed. Law enforcement cannot prolong a traffic stop even for a few minutes to conduct a K-9 sniff unless they have independent **Reasonable Suspicion** of a drug offense. A dog sniff conducted during a lawful stop is constitutional (**Illinois v. Caballes**), but only if it does not prolong the stop by even a single second.

#### D. Identification Requirements
Under **Hiibel v. Sixth Judicial District Court**, a citizen is only obligated to provide their name during a lawful Terry stop if the state has a valid "stop and identify" statute. If no such statute exists, or if the officer does not have **Reasonable Suspicion** to initiate a Terry stop, the citizen has no legal obligation to provide identification. In a traffic stop, the driver must present their driver's license, registration, and insurance, but passengers generally have no obligation to identify themselves unless independent reasonable suspicion exists.

#### E. Recording Police in Public
Our First Amendment right to record police officers performing their duties in public spaces is clearly established, provided the recording does not physically interfere with law enforcement operations. Officers cannot confiscate, search, or delete recordings without a warrant, and doing so constitutes a severe constitutional violation.

#### F. Invocation of Silence
Under **Berghuis v. Thompkins** and **Salinas v. Texas**, simply remaining silent is insufficient to invoke your Fifth Amendment privilege. You must **explicitly** and **unambiguously** state your invocation (e.g., *"I am invoking my right to remain silent. I will not answer questions without an attorney."*).

---

## IV. PROFESSIONAL CONSTITUTIONAL ASSERTION SCRIPTS

This section provides highly precise, professional, and non-confrontational dialogue scripts designed to assert your constitutional protections calmly and lawfully. These scripts are structured using **NEPQ** principles to shift the burden of legal justification onto law enforcement while establishing an undeniable record for subsequent litigation.

### De-escalation & Preserving the Record
1. **Tone:** Maintain a calm, respectful, and professional tone at all times. Do not raise your voice, use profanity, or adopt an aggressive posture.
2. **Body Language:** Keep your hands visible (preferably on the steering wheel or at your sides) and avoid sudden movements.
3. **Avoiding Accidental Consent:** Never use ambiguous phrases like *"I guess so"* or *"Go ahead."* Always use clear, absolute assertions.
4. **Preserving the Record:** If you are recording, state calmly: *"Officer, I am recording this encounter for our mutual safety and to preserve a professional record."*

---

### Dialogue Scripts

#### 1. General Encounter Scripts
* **To clarify your legal status:**
  > *"Officer, am I free to leave, or am I being detained?"*
* **If the officer states you are being detained:**
  > *"What is the specific, articulable legal basis for this detention?"*
* **If the officer continues to ask questions:**
  > *"I want to be cooperative, but I am invoking my right to remain silent. I will not answer any questions without my attorney present."*

#### 2. Fourth Amendment Scripts
* **If asked for permission to search your person, vehicle, or property:**
  > *"I do not consent to any searches of my person, vehicle, or possessions."*
* **If the officer insists on searching without consent:**
  > *"I am not consenting to this search. I am complying with your commands under protest, but I do not waive any of my constitutional rights. Please preserve this record."*
* **If ordered out of the vehicle:**
  > *"I am exiting the vehicle because you are ordering me to do so, but I do not consent to any searches of my vehicle or my person."*

#### 3. Fifth Amendment Scripts
* **To explicitly invoke your right to remain silent:**
  > *"I am invoking my Fifth Amendment right to remain silent. I will not answer any questions."*
* **To request counsel during any questioning:**
  > *"I want my attorney present before I answer any questions. I am invoking my right to counsel."*

#### 4. Traffic Stop Scripts (Driver & Passenger)
* **Driver Interaction:**
  > *"Officer, here are my license, registration, and insurance. Am I being detained for a specific traffic infraction, or am I free to go?"*
* **Passenger Interaction:**
  > *"Officer, as a passenger, am I suspected of a crime, or am I free to leave?"*
* **If the officer prolongs the stop after issuing a ticket or warning:**
  > *"Has the traffic investigation been completed? Am I free to go now?"*
* **If asked to wait for a K-9 unit:**
  > *"I do not consent to being detained further. What is the reasonable suspicion that justifies prolonging this stop?"*

---

## V. BRADY / GIGLIO / OFFICER CREDIBILITY DOCTRINE

The integrity of the judicial system relies entirely on the truthfulness of the evidence presented. When law enforcement officers engage in dishonesty, fabricate evidence, or withhold critical information, they violate the core tenets of the United States Constitution. This section outlines the constitutional framework governing officer credibility and the prosecution's absolute duty to disclose exculpatory and impeachment evidence.

### The Constitutional Duty of Disclosure
Under the Fourteenth Amendment's Due Process Clause, the prosecution has an affirmative, constitutional duty to disclose any evidence favorable to the accused that is material to either guilt or punishment. This obligation, known as the **Brady/Giglio Doctrine**, represents a critical check on government power, ensuring that trials are fair and that the state cannot secure convictions by suppressing the truth.

### Core Case Law Matrix (Credibility Layer)

### Brady v. Maryland, 373 U.S. 83 (1963)

#### 1. Core Constitutional Question
* **Amendment Implicated:** **Fourteenth Amendment (Due Process Clause)**
* **Challenged Authority:** Limits of police authority during warrantless searches, detentions, or interrogations.
* **Legal Standard Evaluated:** The Court evaluated whether the specific law enforcement action met the constitutional threshold required by the **Fourteenth Amendment (Due Process Clause)**.

**Constitutional Question:**
> Was the petitioner denied a federal constitutional right when the Maryland Court of Appeals restricted his new trial to the question of punishment, rather than including the question of guilt, after the prosecution withheld exculpatory evidence?

#### 2. Fact Pattern
John Brady and Charles Boblit were convicted of first-degree murder and sentenced to death in Maryland. Brady admitted participation but claimed Boblit did the actual killing. Prior to trial, Brady's counsel requested Boblit's extrajudicial statements, but one in which Boblit admitted the actual killing was withheld by the prosecution. After his conviction was affirmed, Brady discovered the suppressed statement. The Maryland Court of Appeals held that the suppression denied Brady due process and remanded for a new trial on punishment only, not guilt, believing the suppressed confession would not have reduced the offense below first-degree murder.

#### 3. Supreme Court Holding
* **Vote Margin:** **Vote 7-2**
* **Majority Author:** **Justice Douglas**
* **Ruling Summary:** The suppression by the prosecution of evidence favorable to an accused upon request violates due process where the evidence is material either to guilt or to punishment. However, the Court affirmed the Maryland Court of Appeals' decision to limit the new trial to the question of punishment, as the suppressed evidence was only material to the punishment phase.

**Key Constitutional Test & Doctrinal Rule:**
The 'Brady rule' establishes that the suppression by the prosecution of evidence favorable to an accused upon request violates due process where the evidence is material either to guilt or to punishment, irrespective of the good faith or bad faith of the prosecution. This rule ensures a fair trial by preventing prosecutors from withholding evidence that could exculpate the defendant or reduce their sentence.

**Key Concurrences or Dissents:**
Justice White (concur): Agreed with the Court's decision to affirm the Maryland Court of Appeals' ruling but believed the Court should not have reached the due process question, as the state had not cross-petitioned or challenged the ruling below. He argued that the federal question remained whether denying a new trial on guilt as well as punishment deprived Brady of equal protection.

#### 4. Operational Constitutional Principle
Based on **Brady v. Maryland, 373 U.S. 83 (1963)**, the operational boundaries are defined as follows:
* **What Government CAN Legally Do:** Law enforcement is permitted to act within the specific standard established (e.g., order drivers/passengers out of a vehicle as a de minimis safety measure, conduct a brief patdown if reasonable suspicion of being armed and dangerous exists).
* **What Government CANNOT Legally Do:** Law enforcement cannot exceed the temporal or spatial scope of the stop (e.g., prolong a traffic stop for a K-9 sniff without independent reasonable suspicion, conduct a full search under the guise of a Terry patdown).
* **Required Threshold:** The specific constitutional threshold (e.g., **Reasonable Articulable Suspicion**, **Probable Cause**, or **Explicit Invocation**) must be established before government authority can be lawfully exercised.

#### 5. Sovereign Shield Application
Under the **Sovereign Shield** framework, citizens must apply this case law calmly and non-confrontationally:
* **Encounter Protocol:** If stopped or questioned, immediately establish your status by asking, *"Am I free to leave?"* or *"Am I being detained?"*
* **Assertion of Rights:** If the officer asks questions, state clearly and unambiguously: *"I am invoking my right to remain silent."*
* **Consent Refusal:** If asked for permission to search, state: *"I do not consent to any searches."* This preserves your right to challenge any subsequent search under the **Exclusionary Rule**.
* **Calm Demeanor:** Maintain a polite, calm tone. Do not physically resist or engage in legal arguments on the street. Let your verbal assertions establish the record.

#### 6. Modern Limitations or Later Modifications
* **Doctrinal Evolution:** Giglio v. United States (1972): Expanded Brady to include impeachment evidence. United States v. Agurs (1976): Clarified materiality standard, stating that if the omitted evidence creates a reasonable doubt that did not otherwise exist, constitutional error has been committed. Kyles v. Whitley (1995): Emphasized that the prosecutor has an affirmative duty to disclose exculpatory evidence, even if not specifically requested by the defense.
* **Current Standing:** This case remains binding federal precedent, defining the baseline for modern constitutional litigation under **42 U.S.C. § 1983** and the admissibility of evidence under the **Exclusionary Rule**.

**Verified Majority Quote:**
> "We now hold that the suppression by the prosecution of evidence favorable to an accused upon request violates due process where the evidence is material either to guilt or to punishment, irrespective of the good faith or bad faith of the prosecution." — Brady v. Maryland, 373 U.S. at 87

---

### Giglio v. United States, 405 U.S. 150 (1972)

#### 1. Core Constitutional Question
* **Amendment Implicated:** **Fifth Amendment**
* **Challenged Authority:** Limits of police authority during warrantless searches, detentions, or interrogations.
* **Legal Standard Evaluated:** The Court evaluated whether the specific law enforcement action met the constitutional threshold required by the **Fifth Amendment**.

**Constitutional Question:**
> Is the prosecution’s failure to disclose a promise of immunity made to a key witness grounds for a new trial?

#### 2. Fact Pattern
John Giglio was convicted of passing forged money orders. While his appeal was pending, Giglio’s counsel discovered new evidence: the prosecution failed to disclose a promise of immunity to a key witness in exchange for testimony. The district court denied Giglio’s motion for a new trial, finding the error did not affect the verdict. The Court of Appeals affirmed this decision.

#### 3. Supreme Court Holding
* **Vote Margin:** **Vote 7-0**
* **Majority Author:** **Chief Justice Warren E. Burger**
* **Ruling Summary:** The Supreme Court reversed the conviction and remanded the case for a new trial, holding that the prosecution's failure to disclose a promise of immunity to a key witness violated due process.

**Key Constitutional Test & Doctrinal Rule:**
The Court established that when the reliability of a given witness may be determinative of guilt or innocence, nondisclosure of evidence affecting credibility falls within the rule of Brady v. Maryland. This means that if undisclosed evidence could reasonably be taken to put the whole case in such a different light as to undermine confidence in the verdict, it constitutes a due process violation.

**Key Concurrences or Dissents:**
Unanimous 7-0 decision. Chief Justice Warren E. Burger delivered the opinion of the Court. There were no concurring or dissenting opinions, demonstrating the Court's unified stance on the extension of Brady to witness credibility.

#### 4. Operational Constitutional Principle
Based on **Giglio v. United States, 405 U.S. 150 (1972)**, the operational boundaries are defined as follows:
* **What Government CAN Legally Do:** Law enforcement is permitted to act within the specific standard established (e.g., order drivers/passengers out of a vehicle as a de minimis safety measure, conduct a brief patdown if reasonable suspicion of being armed and dangerous exists).
* **What Government CANNOT Legally Do:** Law enforcement cannot exceed the temporal or spatial scope of the stop (e.g., prolong a traffic stop for a K-9 sniff without independent reasonable suspicion, conduct a full search under the guise of a Terry patdown).
* **Required Threshold:** The specific constitutional threshold (e.g., **Reasonable Articulable Suspicion**, **Probable Cause**, or **Explicit Invocation**) must be established before government authority can be lawfully exercised.

#### 5. Sovereign Shield Application
Under the **Sovereign Shield** framework, citizens must apply this case law calmly and non-confrontationally:
* **Encounter Protocol:** If stopped or questioned, immediately establish your status by asking, *"Am I free to leave?"* or *"Am I being detained?"*
* **Assertion of Rights:** If the officer asks questions, state clearly and unambiguously: *"I am invoking my right to remain silent."*
* **Consent Refusal:** If asked for permission to search, state: *"I do not consent to any searches."* This preserves your right to challenge any subsequent search under the **Exclusionary Rule**.
* **Calm Demeanor:** Maintain a polite, calm tone. Do not physically resist or engage in legal arguments on the street. Let your verbal assertions establish the record.

#### 6. Modern Limitations or Later Modifications
* **Doctrinal Evolution:** United States v. Ruiz (2002) held that the Constitution does not require the government to disclose impeachment information prior to entering a plea agreement.
* **Current Standing:** This case remains binding federal precedent, defining the baseline for modern constitutional litigation under **42 U.S.C. § 1983** and the admissibility of evidence under the **Exclusionary Rule**.

**Verified Majority Quote:**
> "When the 'reliability of a given witness may well be determinative of guilt or innocence,' nondisclosure of evidence affecting credibility falls within this general rule." — Giglio v. United States, 405 U.S. at 154

---

### Napue v. Illinois, 360 U.S. 264 (1959)

#### 1. Core Constitutional Question
* **Amendment Implicated:** **Fourteenth Amendment**
* **Challenged Authority:** Limits of police authority during warrantless searches, detentions, or interrogations.
* **Legal Standard Evaluated:** The Court evaluated whether the specific law enforcement action met the constitutional threshold required by the **Fourteenth Amendment**.

**Constitutional Question:**
> The question presented is whether the failure of the prosecutor to correct the testimony of a witness, which the prosecutor knew to be false, denied the petitioner due process of law in violation of the Fourteenth Amendment to the Constitution of the United States.

#### 2. Fact Pattern
Petitioner Henry Napue was convicted of murder. The principal state witness, an accomplice named George Hamer, falsely testified that he had received no promise of consideration for his testimony, a fact known to the Assistant State's Attorney who had, in fact, promised him consideration. The prosecutor did nothing to correct this false testimony. The Illinois Supreme Court affirmed Napue's conviction, finding the prosecutor knew of the false testimony but held no relief was due because the jury was apprised of other grounds for Hamer's interest. Napue sought relief, alleging a due process violation.

#### 3. Supreme Court Holding
* **Vote Margin:** **Vote 9-0**
* **Majority Author:** **Chief Justice Earl Warren**
* **Ruling Summary:** The failure of the prosecutor to correct the false testimony of the principal state witness, which the prosecutor knew to be false, denied the petitioner due process of law in violation of the Fourteenth Amendment. The judgment of the Illinois Supreme Court was reversed.

**Key Constitutional Test & Doctrinal Rule:**
The principle that a State may not knowingly use false evidence, including false testimony, to obtain a tainted conviction, is implicit in any concept of ordered liberty. This principle applies even when the false testimony goes only to the credibility of the witness, not directly to guilt. The State has a duty to correct false testimony when it appears, even if it did not solicit it.

**Key Concurrences or Dissents:**
Unanimous 9-0 decision. Chief Justice Earl Warren delivered the opinion of the Court. There were no concurring or dissenting opinions, establishing a solid baseline for the prohibition of knowing use of false testimony.

#### 4. Operational Constitutional Principle
Based on **Napue v. Illinois, 360 U.S. 264 (1959)**, the operational boundaries are defined as follows:
* **What Government CAN Legally Do:** Law enforcement is permitted to act within the specific standard established (e.g., order drivers/passengers out of a vehicle as a de minimis safety measure, conduct a brief patdown if reasonable suspicion of being armed and dangerous exists).
* **What Government CANNOT Legally Do:** Law enforcement cannot exceed the temporal or spatial scope of the stop (e.g., prolong a traffic stop for a K-9 sniff without independent reasonable suspicion, conduct a full search under the guise of a Terry patdown).
* **Required Threshold:** The specific constitutional threshold (e.g., **Reasonable Articulable Suspicion**, **Probable Cause**, or **Explicit Invocation**) must be established before government authority can be lawfully exercised.

#### 5. Sovereign Shield Application
Under the **Sovereign Shield** framework, citizens must apply this case law calmly and non-confrontationally:
* **Encounter Protocol:** If stopped or questioned, immediately establish your status by asking, *"Am I free to leave?"* or *"Am I being detained?"*
* **Assertion of Rights:** If the officer asks questions, state clearly and unambiguously: *"I am invoking my right to remain silent."*
* **Consent Refusal:** If asked for permission to search, state: *"I do not consent to any searches."* This preserves your right to challenge any subsequent search under the **Exclusionary Rule**.
* **Calm Demeanor:** Maintain a polite, calm tone. Do not physically resist or engage in legal arguments on the street. Let your verbal assertions establish the record.

#### 6. Modern Limitations or Later Modifications
* **Doctrinal Evolution:** Brady v. Maryland (1963): established the requirement for prosecutors to disclose exculpatory evidence to the defense. Giglio v. United States (1972): clarified that the Brady rule extends to evidence affecting the credibility of government witnesses.
* **Current Standing:** This case remains binding federal precedent, defining the baseline for modern constitutional litigation under **42 U.S.C. § 1983** and the admissibility of evidence under the **Exclusionary Rule**.

**Verified Majority Quote:**
> "The principle that a State may not knowingly use false evidence, including false testimony, to obtain a tainted conviction, implicit in any concept of ordered liberty, does not cease to apply merely because the false testimony goes only to the credibility of the witness." — Napue v. Illinois, 360 U.S. at 269

---


### Practical Applications: Officer Dishonesty & Credibility
In the real world, the **Brady/Giglio** doctrine transforms officer dishonesty from a moral failing into a powerful procedural weapon for the defense:
1. **The Consequences of a Lie:** If an officer knowingly makes a false statement in a police report, during a deposition, or on the witness stand, that lie constitutes **impeachment material**. The prosecution is constitutionally required to disclose this dishonesty to the defense in any subsequent case where that officer is a material witness.
2. **Brady/Giglio Lists:** Many prosecuting offices maintain confidential or public databases of officers with documented histories of dishonesty, bias, or disciplinary infractions. An officer placed on a **Brady List** is severely compromised; their testimony can be easily impeached, often forcing the prosecution to dismiss charges or enter highly favorable plea deals.
3. **Bodycam Contradictions:** With the widespread adoption of Body-Worn Cameras (BWC), contradictions between an officer's written report and the actual video footage have become the most common source of Brady material. If an officer writes that a suspect "reached for their waistband" but the bodycam shows the suspect's hands were in the air, the report is demonstrably false. This contradiction must be disclosed and can be used to suppress evidence and dismiss charges.
4. **The Critical Element of Timing:** Timelines are the bedrock of credibility. Officers must document their actions chronologically. If dispatch logs show a vehicle was stopped at 14:02, but the officer's report claims the stop occurred at 14:15 to justify a subsequent search or K-9 deployment, the 13-minute discrepancy constitutes critical impeachment evidence under **Giglio**.

---

## VI. EVIDENCE PRESERVATION & DEFENSIVE DOCUMENTATION

Constitutional rights are entirely useless if you cannot prove they were violated. In the courtroom, a judge or jury does not rely on emotional arguments or uncorroborated assertions. They rely on **admissible evidence**. This section provides the practical, operational framework for securing, documenting, and preserving evidence of constitutional violations during and immediately following law enforcement encounters.

### 1. Lawful Recording of Police
* **The First Amendment Right:** You have a clearly established constitutional right to record police officers performing their duties in public spaces, provided you do not physically interfere with their operations.
* **Operational Protocol:** Keep your recording device visible. State calmly on the recording: *"Officer, I am recording this encounter for our mutual safety and to preserve an accurate record of our professional interaction."*
* **Seizure of Devices:** Officers cannot confiscate, search, or delete your recordings without a warrant. If an officer commands you to stop recording or attempts to seize your device, state clearly: *"I am not interfering with your duties. I do not consent to the seizure or search of my phone."*

### 2. Immediate Post-Encounter Documentation
The moments immediately following an encounter are critical. You must act systematically to preserve perishable evidence before it is overwritten, lost, or fabricated:
* **The Golden Hour Narrative:** Write a detailed, chronological, and objective narrative of the encounter immediately. Do not include emotional or inflammatory language. Focus on exact quotes, times, physical actions, and officer names/badge numbers.
* **Documenting Injuries:** If you or anyone else suffered physical injuries during the encounter, immediately take high-resolution photographs from multiple angles under consistent lighting. Seek professional medical evaluation and request copies of all medical records, diagnostic scans, and physician notes.
* **Witness Collection:** Identify any bystanders who witnessed the encounter. Secure their full names, phone numbers, email addresses, and brief written or recorded statements detailing what they observed.

### 3. Systematic Evidence Acquisition (FOIA & Public Records)
Do not rely on the police department to voluntarily preserve or produce evidence. You must deploy formal legal requests to compel the preservation and disclosure of critical data:
* **The Preservation Letter:** Immediately send a formal **Evidence Preservation Request** to the police department's chief and the city/county attorney. This legally puts them on notice that litigation is anticipated and commands them to preserve all electronic data, including bodycam footage, dashcam footage, dispatch logs, and radio transmissions.
* **Public Records Requests:** File a formal public records request under the **Freedom of Information Act (FOIA)** (for federal agencies) or your state's public records act (e.g., the **California Public Records Act**). Request all CAD (Computer-Aided Dispatch) logs, MDC (Mobile Data Computer) messages sent between patrol cars, and audio recordings of 911 calls related to your incident.

---

### SAMPLE TEMPLATES

#### A. Sample Evidence Preservation Request

```
[Date]

TO: Chief of Police, [Name of Police Department]
    [Department Address]
    [City, State, Zip]

CC: Office of the City/County Attorney
    [Attorney Office Address]

RE: EVIDENCE PRESERVATION DEMAND / NOTICE OF ANTICIPATED LITIGATION
    Incident Date: [Date of Incident]
    Approximate Time: [Time]
    Location: [Specific Location]
    Involved Officers: [Names, Badge Numbers, and Patrol Car Numbers, if known]
    Target Individual: [Your Full Name]

Dear Chief of Police and Counsel:

Please accept this letter as a formal demand for the preservation of all evidence, electronic data, and physical materials related to the above-referenced incident. This request is made in anticipation of federal civil rights litigation under 42 U.S.C. § 1983 and state law claims.

You are hereby commanded to immediately preserve, lock, and prevent the destruction, overwriting, or alteration of the following materials:
1. All Body-Worn Camera (BWC) audio and video recordings captured by any and all officers present at the scene, including but not limited to Officers [Names/Badge Numbers].
2. All Dashboard Camera (dashcam) audio and video recordings from all patrol vehicles dispatched to or present at the scene.
3. All Computer-Aided Dispatch (CAD) logs, dispatch audio recordings, and radio transmissions related to this incident or the dispatch of officers to the scene.
4. All Mobile Data Terminal (MDT) or Mobile Data Computer (MDC) text messages, chat logs, and digital communications sent between officers or dispatchers regarding this incident.
5. All police reports, supplemental reports, arrest logs, use of force reports, and internal memo drafts concerning the target individual.
6. All station house, holding cell, or booking area surveillance video and audio recordings.

Failure to preserve these materials after receiving this formal notice constitutes intentional spoliation of evidence, which will result in a judicial instruction for an adverse inference in any subsequent civil litigation.

Sincerely,

[Your Signature]
[Your Printed Name]
[Your Contact Information]
```

#### B. Sample Public Records Request (FOIA / State Act)

```
[Date]

TO: Public Records Officer / Custodian of Records
    [Name of Police Department]
    [Department Address]
    [City, State, Zip]

RE: PUBLIC RECORDS ACT REQUEST — CAD LOGS & BWC FOOTAGE

Dear Custodian of Records:

Pursuant to [Insert State Public Records Act, e.g., California Public Records Act (Gov. Code § 7920 et seq.)] or the federal Freedom of Information Act (5 U.S.C. § 552), I hereby request the disclosure and production of the following public records:

1. The complete Computer-Aided Dispatch (CAD) log (detailed incident report) for Incident Number [Number, if known] or for any police activity occurring on [Date] between the hours of [Start Time] and [End Time] at or near the location of [Specific Address/Intersection].
2. All audio recordings of 911 calls, dispatch transmissions, and radio traffic associated with the aforementioned police activity.
3. The final, unredacted police reports, supplemental reports, and arrest logs filed under Case Number [Number, if known] involving [Your Name].

If any portion of these records is deemed exempt from disclosure under applicable law, please produce all reasonably segregable, non-exempt portions. If you deny this request in whole or in part, please state the specific statutory exemption relied upon and provide a written explanation of your denial.

I agree to pay reasonable duplication fees up to $[Amount, e.g., $50.00]. If the fees are expected to exceed this amount, please contact me prior to processing.

Sincerely,

[Your Signature]
[Your Printed Name]
[Your Contact Information]
```

---

### INCIDENT DOCUMENTATION CHECKLIST

- [ ] **Activate Recording:** Turn on your phone's video/audio recorder immediately upon realizing an encounter is imminent. Lock the screen to prevent unauthorized shutoff.
- [ ] **Note Officer Identifiers:** Verbally state the officer's name, badge number, and patrol vehicle license plate into the recording.
- [ ] **State Rights Clearly:** Verbally assert your Fourth and Fifth Amendment protections using the NEPQ-style scripts.
- [ ] **Secure Bystander Info:** Before leaving the scene, obtain names and phone numbers of any witnesses.
- [ ] **Write Narrative:** Draft your chronological Golden Hour narrative within 60 minutes of the encounter.
- [ ] **Photograph Injuries:** Capture high-resolution photographs of any physical injuries or property damage.
- [ ] **Send Preservation Demand:** Mail the Evidence Preservation Request via certified mail with return receipt requested within 48 hours.
- [ ] **File Public Records Request:** Submit your public records request to obtain CAD logs and dispatch recordings.

---

## VII. 42 U.S.C. § 1983 CIVIL RIGHTS LITIGATION

When a government actor crosses the line from lawful authority into constitutional violation, the primary vehicle for accountability and civil recourse is **42 U.S.C. § 1983**. This federal statute allows individuals to sue state and local officials in federal court for damages, declaratory relief, and injunctions. However, federal civil rights litigation is a highly complex legal battlefield where the government is protected by formidable doctrines. This section outlines the mechanics of Section 1983 litigation, the standards of liability, and the primary defenses that must be overcome.

### The Standard of Municipal and Officer Liability
To succeed in a Section 1983 lawsuit, a plaintiff must prove that: (1) the defendant deprived them of a right secured by the Constitution or laws of the United States, and (2) the defendant acted under "color of state law." 

However, a critical distinction exists between individual liability and municipal liability:
* **Individual Liability:** An individual officer can be held personally liable for damages if their personal actions directly caused the constitutional violation.
* **Municipal Liability:** Under the landmark **Monell** doctrine, a city, county, or municipality cannot be held liable under Section 1983 solely because they employ an offending officer (no *respondeat superior* liability). Instead, the plaintiff must prove that the municipality itself caused the violation through an official policy, custom, or practice.

### Core Case Law Matrix (Litigation Layer)

### Monell v. Department of Social Services, 436 U.S. 658 (1978)

#### 1. Core Constitutional Question
* **Amendment Implicated:** **Fourteenth Amendment**
* **Challenged Authority:** Limits of police authority during warrantless searches, detentions, or interrogations.
* **Legal Standard Evaluated:** The Court evaluated whether the specific law enforcement action met the constitutional threshold required by the **Fourteenth Amendment**.

**Constitutional Question:**
> Are local government officials and organizations, when sued in their official capacity, considered "persons" for the purpose of liability for back wages under 42 U.S.C. § 1983?

#### 2. Fact Pattern
Female employees of the Department of Social Services and the Board of Education of New York City brought a class action against their employers, alleging that an official policy compelled pregnant employees to take unpaid leaves of absence before medically necessary. The District Court found the policy unconstitutional but held the city immune from back pay and dismissed the injunction claim as moot. The Court of Appeals affirmed, relying on Monroe v. Pape, which held municipalities immune from § 1983 suits.

#### 3. Supreme Court Holding
* **Vote Margin:** **Vote 7-2**
* **Majority Author:** **Justice Brennan**
* **Ruling Summary:** Local governmental bodies and local officials sued in their official capacities can be sued directly under 42 U.S.C. § 1983 for monetary, declaratory, and injunctive relief when the alleged unconstitutional action implements or executes an official policy, custom, ordinance, regulation, or decision. The Court overruled Monroe v. Pape insofar as it held that local governments are wholly immune from suit under § 1983, but clarified that municipalities cannot be held liable under a respondeat superior theory.

**Key Constitutional Test & Doctrinal Rule:**
The Court established that municipalities are "persons" subject to suit under 42 U.S.C. § 1983 for constitutional violations. However, municipal liability is not based on respondeat superior; it arises only when the constitutional deprivation results from an official policy, custom, ordinance, regulation, or decision officially adopted or promulgated by the municipality.

**Key Concurrences or Dissents:**
Justice Powell (concur): Emphasized the unusual but crucial decision to overrule Monroe v. Pape, aligning municipal liability with precedents for school boards in civil rights cases. Justice Stevens (concur): Concurred in the decision's explanation but not in purely background sections. Justice Rehnquist (dissent): Argued against overruling Monroe v. Pape due to strong precedent supporting municipal immunity, stating the majority relied on insufficient evidence (a rejected amendment to the Act). Chief Justice Burger joined this dissent.

#### 4. Operational Constitutional Principle
Based on **Monell v. Department of Social Services, 436 U.S. 658 (1978)**, the operational boundaries are defined as follows:
* **What Government CAN Legally Do:** Law enforcement is permitted to act within the specific standard established (e.g., order drivers/passengers out of a vehicle as a de minimis safety measure, conduct a brief patdown if reasonable suspicion of being armed and dangerous exists).
* **What Government CANNOT Legally Do:** Law enforcement cannot exceed the temporal or spatial scope of the stop (e.g., prolong a traffic stop for a K-9 sniff without independent reasonable suspicion, conduct a full search under the guise of a Terry patdown).
* **Required Threshold:** The specific constitutional threshold (e.g., **Reasonable Articulable Suspicion**, **Probable Cause**, or **Explicit Invocation**) must be established before government authority can be lawfully exercised.

#### 5. Sovereign Shield Application
Under the **Sovereign Shield** framework, citizens must apply this case law calmly and non-confrontationally:
* **Encounter Protocol:** If stopped or questioned, immediately establish your status by asking, *"Am I free to leave?"* or *"Am I being detained?"*
* **Assertion of Rights:** If the officer asks questions, state clearly and unambiguously: *"I am invoking my right to remain silent."*
* **Consent Refusal:** If asked for permission to search, state: *"I do not consent to any searches."* This preserves your right to challenge any subsequent search under the **Exclusionary Rule**.
* **Calm Demeanor:** Maintain a polite, calm tone. Do not physically resist or engage in legal arguments on the street. Let your verbal assertions establish the record.

#### 6. Modern Limitations or Later Modifications
* **Doctrinal Evolution:** Owen v. City of Independence (1980): Held that municipalities do not enjoy qualified immunity from § 1983 suits. Pembaur v. City of Cincinnati (1986): Clarified that municipal liability may attach for a single decision by municipal policymakers under certain circumstances. City of Canton v. Harris (1989): Established that municipal liability for failure to train can arise under § 1983 where the failure amounts to deliberate indifference to the rights of persons with whom the police come into contact.
* **Current Standing:** This case remains binding federal precedent, defining the baseline for modern constitutional litigation under **42 U.S.C. § 1983** and the admissibility of evidence under the **Exclusionary Rule**.

**Verified Majority Quote:**
> "Our analysis of the legislative history of the Civil Rights Act of 1871 compels the conclusion that Congress did intend municipalities and other local government units to be included among those persons to whom § 1983 applies." — Monell v. Department of Social Services, 436 U.S. at 690

---

### Graham v. Connor, 490 U.S. 386 (1989)

#### 1. Core Constitutional Question
* **Amendment Implicated:** **Fourth Amendment**
* **Challenged Authority:** Limits of police authority during warrantless searches, detentions, or interrogations.
* **Legal Standard Evaluated:** The Court evaluated whether the specific law enforcement action met the constitutional threshold required by the **Fourth Amendment**.

**Constitutional Question:**
> What constitutional standard governs a free citizen's claim that law enforcement officials used excessive force in the course of an arrest, investigatory stop, or other seizure? Specifically, must such claims be analyzed under the Fourth Amendment's 'objective reasonableness' standard, rather than a subjective standard like 'malicious and sadistic intent' under the Fourteenth Amendment?

#### 2. Fact Pattern
Dethorne Graham, a diabetic, experienced an insulin reaction and asked a friend to drive him to a store for orange juice. After quickly entering and leaving the store, he asked to be driven to a friend's house. Officer M.S. Connor, observing Graham's behavior, became suspicious and initiated an investigative stop. During the stop, backup officers arrived, handcuffed Graham, and allegedly used excessive force, causing him multiple injuries, including a broken foot. Graham filed a § 1983 suit, alleging excessive force in violation of his rights, but the lower courts applied a subjective 'good faith' or 'malicious and sadistic' standard under the Fourteenth Amendment.

#### 3. Supreme Court Holding
* **Vote Margin:** **Vote 9-0**
* **Majority Author:** **Chief Justice William H. Rehnquist**
* **Ruling Summary:** All claims that law enforcement officials have used excessive force in the course of an arrest, investigatory stop, or other 'seizure' of a free citizen are properly analyzed under the Fourth Amendment's 'objective reasonableness' standard, rather than under a substantive due process standard.

**Key Constitutional Test & Doctrinal Rule:**
The case established the 'objective reasonableness' standard for evaluating claims of excessive force used by law enforcement officials during an arrest, investigatory stop, or other seizure of a free citizen. This standard requires judging the officer's actions from the perspective of a reasonable officer on the scene, considering the totality of the circumstances, without regard to the officer's underlying intent or motivation. Factors include the severity of the crime, the immediate threat posed by the suspect, and whether the suspect is actively resisting or attempting to evade arrest.

**Key Concurrences or Dissents:**
Justice Blackmun (concur): Argued there was not sufficient precedent to hold that claims of excessive force will never be subject to Fourteenth Amendment substantive due process review.

#### 4. Operational Constitutional Principle
Based on **Graham v. Connor, 490 U.S. 386 (1989)**, the operational boundaries are defined as follows:
* **What Government CAN Legally Do:** Law enforcement is permitted to act within the specific standard established (e.g., order drivers/passengers out of a vehicle as a de minimis safety measure, conduct a brief patdown if reasonable suspicion of being armed and dangerous exists).
* **What Government CANNOT Legally Do:** Law enforcement cannot exceed the temporal or spatial scope of the stop (e.g., prolong a traffic stop for a K-9 sniff without independent reasonable suspicion, conduct a full search under the guise of a Terry patdown).
* **Required Threshold:** The specific constitutional threshold (e.g., **Reasonable Articulable Suspicion**, **Probable Cause**, or **Explicit Invocation**) must be established before government authority can be lawfully exercised.

#### 5. Sovereign Shield Application
Under the **Sovereign Shield** framework, citizens must apply this case law calmly and non-confrontationally:
* **Encounter Protocol:** If stopped or questioned, immediately establish your status by asking, *"Am I free to leave?"* or *"Am I being detained?"*
* **Assertion of Rights:** If the officer asks questions, state clearly and unambiguously: *"I am invoking my right to remain silent."*
* **Consent Refusal:** If asked for permission to search, state: *"I do not consent to any searches."* This preserves your right to challenge any subsequent search under the **Exclusionary Rule**.
* **Calm Demeanor:** Maintain a polite, calm tone. Do not physically resist or engage in legal arguments on the street. Let your verbal assertions establish the record.

#### 6. Modern Limitations or Later Modifications
* **Doctrinal Evolution:** UNVERIFIED — requires primary source confirmation.
* **Current Standing:** This case remains binding federal precedent, defining the baseline for modern constitutional litigation under **42 U.S.C. § 1983** and the admissibility of evidence under the **Exclusionary Rule**.

**Verified Majority Quote:**
> "The 'reasonableness' of a particular use of force must be judged from the perspective of a reasonable officer on the scene, rather than with the 20/20 vision of hindsight." — Graham v. Connor, 490 U.S. at 396

---

### Tennessee v. Garner, 471 U.S. 1 (1985)

#### 1. Core Constitutional Question
* **Amendment Implicated:** **Fourth Amendment**
* **Challenged Authority:** Limits of police authority during warrantless searches, detentions, or interrogations.
* **Legal Standard Evaluated:** The Court evaluated whether the specific law enforcement action met the constitutional threshold required by the **Fourth Amendment**.

**Constitutional Question:**
> Does a statute authorizing use of deadly force to prevent the escape of any fleeing suspected felon violate the Fourth Amendment, specifically regarding the constitutionality of using such force against an apparently unarmed suspected felon?

#### 2. Fact Pattern
Memphis police officers Elton Hymon and Leslie Wright responded to a 'prowler inside call.' Officer Hymon pursued 15-year-old Edward Eugene Garner, suspected of burglarizing a nearby house, as he fled over a fence. Hymon shot Garner with a hollow tip bullet to prevent his escape, despite being 'reasonably sure' Garner was unarmed. Garner died at the hospital. Garner's father sued under 42 U.S.C. § 1983, alleging violations of his son's constitutional rights. The District Court upheld the Tennessee statute authorizing Hymon's actions, but the U.S. Court of Appeals for the Sixth Circuit reversed, holding that killing a fleeing suspect is a 'seizure' under the Fourth Amendment and only reasonable if the suspect poses a threat.

#### 3. Supreme Court Holding
* **Vote Margin:** **Vote 6-3**
* **Majority Author:** **Justice Byron R. White**
* **Ruling Summary:** The Fourth Amendment prohibits the use of deadly force unless it is necessary to prevent the escape of a fleeing felon and the officer has probable cause to believe that the suspect poses a significant threat of death or serious physical injury to the officer or the community. The Tennessee statute was unconstitutional as applied to prevent the escape of an unarmed fleeing felon.

**Key Constitutional Test & Doctrinal Rule:**
The Court established the 'significant threat' test for the use of deadly force. Under this doctrine, deadly force may not be used by a police officer to prevent the escape of a fleeing suspect unless the officer has probable cause to believe that the suspect poses a significant threat of death or serious physical injury to the officer or others.

**Key Concurrences or Dissents:**
Justice Sandra Day O'Connor (dissent): The majority went too far in invalidating long-standing common law and police practices, which she believed were not contrary to the holding. Chief Justice Warren E. Burger and Justice William H. Rehnquist joined in this dissent.

#### 4. Operational Constitutional Principle
Based on **Tennessee v. Garner, 471 U.S. 1 (1985)**, the operational boundaries are defined as follows:
* **What Government CAN Legally Do:** Law enforcement is permitted to act within the specific standard established (e.g., order drivers/passengers out of a vehicle as a de minimis safety measure, conduct a brief patdown if reasonable suspicion of being armed and dangerous exists).
* **What Government CANNOT Legally Do:** Law enforcement cannot exceed the temporal or spatial scope of the stop (e.g., prolong a traffic stop for a K-9 sniff without independent reasonable suspicion, conduct a full search under the guise of a Terry patdown).
* **Required Threshold:** The specific constitutional threshold (e.g., **Reasonable Articulable Suspicion**, **Probable Cause**, or **Explicit Invocation**) must be established before government authority can be lawfully exercised.

#### 5. Sovereign Shield Application
Under the **Sovereign Shield** framework, citizens must apply this case law calmly and non-confrontationally:
* **Encounter Protocol:** If stopped or questioned, immediately establish your status by asking, *"Am I free to leave?"* or *"Am I being detained?"*
* **Assertion of Rights:** If the officer asks questions, state clearly and unambiguously: *"I am invoking my right to remain silent."*
* **Consent Refusal:** If asked for permission to search, state: *"I do not consent to any searches."* This preserves your right to challenge any subsequent search under the **Exclusionary Rule**.
* **Calm Demeanor:** Maintain a polite, calm tone. Do not physically resist or engage in legal arguments on the street. Let your verbal assertions establish the record.

#### 6. Modern Limitations or Later Modifications
* **Doctrinal Evolution:** Graham v. Connor (1989): Clarified the 'objective reasonableness' standard for excessive force claims under the Fourth Amendment, building upon Garner. Scott v. Harris (2007): Applied the 'objective reasonableness' standard to a high-speed chase, further defining the permissible use of force in light of Garner.
* **Current Standing:** This case remains binding federal precedent, defining the baseline for modern constitutional litigation under **42 U.S.C. § 1983** and the admissibility of evidence under the **Exclusionary Rule**.

**Verified Majority Quote:**
> "Where the suspect poses no immediate threat to the officer and no threat to others, the harm resulting from failing to apprehend him does not justify the use of deadly force to do so." — Tennessee v. Garner, 471 U.S. at 11

---


### The Realities of Civil Rights Litigation: Why Most Lawsuits Fail
Despite clear constitutional violations occurring daily, the vast majority of Section 1983 lawsuits are dismissed before ever reaching a jury. Understanding these structural hurdles is critical to maintaining a realistic, evidence-focused legal posture:
1. **The Qualified Immunity Bar:** As established in **Harlow v. Fitzgerald** and its progeny, qualified immunity shields police officers from personal liability unless their conduct violates "clearly established" law. To prove a right is clearly established, a plaintiff must find existing, binding Supreme Court or federal circuit precedent with a nearly identical fact pattern. If the officer's conduct was unconstitutional, but no prior case has explicitly declared that exact conduct unlawful under identical circumstances, the officer is granted immunity, and the lawsuit is dismissed.
2. **The High Burden of Monell:** Proving municipal liability is exceptionally difficult. A plaintiff must conduct extensive discovery to establish a "widespread custom or practice" or prove that the municipality's failure to train its officers amounted to "deliberate indifference." This requires demonstrating that policymakers knew of a pattern of unconstitutional behavior and consciously chose to ignore it.
3. **The Objective Reasonableness Standard:** Under **Graham v. Connor**, courts are required to judge an officer's use of force from the perspective of a reasonable officer on the scene, without the "20/20 vision of hindsight." This highly deferential standard means that if an officer's split-second decision was reasonable under the circumstances, even if it was ultimately tragic or based on a mistaken perception, no constitutional violation occurred.

---

## VIII. TRAFFIC STOP WARFARE DOCTRINE

The public highway is the most common arena for constitutional conflict. Millions of citizens interact with law enforcement daily during routine traffic stops. To navigate these encounters successfully, one must understand the highly specialized body of Fourth Amendment jurisprudence that governs vehicle stops, pretextual detentions, search authority, and roadside questioning. This is the "Traffic Stop Warfare" doctrine — where minor traffic infractions are systematically used as pretexts for invasive criminal investigations.

### Pretextual Stops & The Irrelevance of Intent
Under **Whren v. United States**, the Supreme Court handed law enforcement a powerful weapon: the pretextual stop. If an officer observes even the most minor traffic infraction (e.g., failing to signal within 100 feet of a turn, an expired registration tag, or a cracked windshield), they have lawful authority to stop the vehicle. The officer's subjective motivations — even if they stopped the vehicle solely on a hunch of drug smuggling or out of personal bias — are completely irrelevant under the Fourth Amendment, as long as an objective traffic violation occurred.

### Core Case Law Matrix (Traffic Stop Layer)

### Whren v. United States, 517 U.S. 806 (1996)

#### 1. Core Constitutional Question
* **Amendment Implicated:** **Fourth Amendment**
* **Challenged Authority:** Limits of police authority during warrantless searches, detentions, or interrogations.
* **Legal Standard Evaluated:** The Court evaluated whether the specific law enforcement action met the constitutional threshold required by the **Fourth Amendment**.

**Constitutional Question:**
> Did the officers conduct an unreasonable search and seizure in violation of the Fourth Amendment?

#### 2. Fact Pattern
Whren and Brown were driving in a 'high drug area.' Some plainclothes officers, while patrolling the neighborhood in an unmarked vehicle, noticed Whren and Brown sitting in a truck at an intersection stop-sign for an usually long time. Suddenly, without signaling, Whren turned his truck and sped away. Observing this traffic violation, the officers stopped the truck. When they approached the vehicle, the officers saw Whren holding plastic bags of crack cocaine. Whren and Brown were arrested on federal drug charges. Before trial, they moved to suppress the evidence contending that the officers used the traffic violation as a pretext for stopping the truck because they lacked either reasonable suspicion or probable cause to stop them on suspicion of drug dealing. The District Court denied the motion to suppress and convicted the petitioners. The Court of Appeals affirmed. The Supreme Court granted certiorari.

#### 3. Supreme Court Holding
* **Vote Margin:** **Vote 9-0**
* **Majority Author:** **Antonin Scalia**
* **Ruling Summary:** as long as officers have a reasonable cause to believe that a traffic violation occurred, they may stop any vehicle. In the present case, the officers had reasonable cause to stop the petitioners for a traffic violation since they sped away from a stop sign at an 'unreasonable speed' and without using their turn signal. Thus, since an actual traffic violation occurred, the ensuing search and seizure of the offending vehicle was reasonable, regardless of what other personal motivations the officers might have had for stopping the vehicle.

**Key Constitutional Test & Doctrinal Rule:**
The Court established that an officer's subjective intentions for stopping a vehicle are irrelevant as long as there is an objectively justifiable reason for the stop, such as a traffic violation. This is known as the 'pretextual stop' doctrine, where a traffic stop is valid even if the officer's primary motivation was to investigate other crimes, provided there was probable cause for the traffic infraction.

**Key Concurrences or Dissents:**
None

#### 4. Operational Constitutional Principle
Based on **Whren v. United States, 517 U.S. 806 (1996)**, the operational boundaries are defined as follows:
* **What Government CAN Legally Do:** Law enforcement is permitted to act within the specific standard established (e.g., order drivers/passengers out of a vehicle as a de minimis safety measure, conduct a brief patdown if reasonable suspicion of being armed and dangerous exists).
* **What Government CANNOT Legally Do:** Law enforcement cannot exceed the temporal or spatial scope of the stop (e.g., prolong a traffic stop for a K-9 sniff without independent reasonable suspicion, conduct a full search under the guise of a Terry patdown).
* **Required Threshold:** The specific constitutional threshold (e.g., **Reasonable Articulable Suspicion**, **Probable Cause**, or **Explicit Invocation**) must be established before government authority can be lawfully exercised.

#### 5. Sovereign Shield Application
Under the **Sovereign Shield** framework, citizens must apply this case law calmly and non-confrontationally:
* **Encounter Protocol:** If stopped or questioned, immediately establish your status by asking, *"Am I free to leave?"* or *"Am I being detained?"*
* **Assertion of Rights:** If the officer asks questions, state clearly and unambiguously: *"I am invoking my right to remain silent."*
* **Consent Refusal:** If asked for permission to search, state: *"I do not consent to any searches."* This preserves your right to challenge any subsequent search under the **Exclusionary Rule**.
* **Calm Demeanor:** Maintain a polite, calm tone. Do not physically resist or engage in legal arguments on the street. Let your verbal assertions establish the record.

#### 6. Modern Limitations or Later Modifications
* **Doctrinal Evolution:** Arizona v. Gant (2009): While not directly overruling Whren, this case narrowed the scope of vehicle searches incident to arrest, limiting police ability to search a vehicle only if the arrestee is unsecured and within reaching distance of the passenger compartment, or if it is reasonable to believe evidence of the offense of arrest might be found in the vehicle. Riley v. California (2014): This case further narrowed search incident to arrest, holding that police generally may not search digital information on a cell phone seized from an individual who has been arrested. The concept of 'vertical narrowing' has been proposed by scholars as a way for lower courts to interpret Whren more narrowly without directly overturning it, focusing on the 'unusually harmful' seizure doctrine within Whren itself.
* **Current Standing:** This case remains binding federal precedent, defining the baseline for modern constitutional litigation under **42 U.S.C. § 1983** and the admissibility of evidence under the **Exclusionary Rule**.

**Verified Majority Quote:**
> "the Fourth Amendment's concern with 'reasonableness' allows certain actions to be taken in certain circumstances, *whatever* the subjective intent." — Whren v. United States, 517 U.S. at 813-816

---

### Arizona v. Gant, 556 U.S. 332 (2009)

#### 1. Core Constitutional Question
* **Amendment Implicated:** **Fourth Amendment**
* **Challenged Authority:** Limits of police authority during warrantless searches, detentions, or interrogations.
* **Legal Standard Evaluated:** The Court evaluated whether the specific law enforcement action met the constitutional threshold required by the **Fourth Amendment**.

**Constitutional Question:**
> Is a search conducted by police officers after handcuffing the defendant and securing the scene a violation of the Fourth Amendment's protection against unreasonable searches and seizures?

#### 2. Fact Pattern
Rodney Gant was arrested on an outstanding warrant for driving with a suspended license. After he was handcuffed and secured in a patrol car, officers searched his vehicle and found a handgun and cocaine. Gant moved to suppress the evidence, arguing the warrantless search violated the Fourth Amendment. The trial court denied the motion, but the Arizona Court of Appeals and Arizona Supreme Court reversed, finding the search unconstitutional because Gant was secured and posed no threat.

#### 3. Supreme Court Holding
* **Vote Margin:** **Vote 5-4**
* **Majority Author:** **Justice Stevens**
* **Ruling Summary:** Police may search a vehicle incident to a recent occupant's arrest only if the arrestee is within reaching distance of the passenger compartment at the time of the search or it is reasonable to believe the vehicle contains evidence of the offense of arrest.

**Key Constitutional Test & Doctrinal Rule:**
The Court established that police may search the passenger compartment of a vehicle incident to a recent occupant’s arrest only if it is reasonable to believe that the arrestee might access the vehicle at the time of the search or that the vehicle contains evidence of the offense of arrest. This narrowed the scope of the search-incident-to-arrest exception to the warrant requirement as previously understood under *New York v. Belton*.

**Key Concurrences or Dissents:**
Justice Scalia (concur): Emphasized that the search incident to arrest exception should be limited to situations where the arrestee is unsecured and within reaching distance, or where there is probable cause to believe evidence of the crime of arrest is in the vehicle. Justice Alito (dissent): Argued the majority improperly overruled *New York v. Belton* and created an unworkable rule for law enforcement. Justice Breyer (dissent): Lamented the Court's inability to create a clear, workable rule for police officers.

#### 4. Operational Constitutional Principle
Based on **Arizona v. Gant, 556 U.S. 332 (2009)**, the operational boundaries are defined as follows:
* **What Government CAN Legally Do:** Law enforcement is permitted to act within the specific standard established (e.g., order drivers/passengers out of a vehicle as a de minimis safety measure, conduct a brief patdown if reasonable suspicion of being armed and dangerous exists).
* **What Government CANNOT Legally Do:** Law enforcement cannot exceed the temporal or spatial scope of the stop (e.g., prolong a traffic stop for a K-9 sniff without independent reasonable suspicion, conduct a full search under the guise of a Terry patdown).
* **Required Threshold:** The specific constitutional threshold (e.g., **Reasonable Articulable Suspicion**, **Probable Cause**, or **Explicit Invocation**) must be established before government authority can be lawfully exercised.

#### 5. Sovereign Shield Application
Under the **Sovereign Shield** framework, citizens must apply this case law calmly and non-confrontationally:
* **Encounter Protocol:** If stopped or questioned, immediately establish your status by asking, *"Am I free to leave?"* or *"Am I being detained?"*
* **Assertion of Rights:** If the officer asks questions, state clearly and unambiguously: *"I am invoking my right to remain silent."*
* **Consent Refusal:** If asked for permission to search, state: *"I do not consent to any searches."* This preserves your right to challenge any subsequent search under the **Exclusionary Rule**.
* **Calm Demeanor:** Maintain a polite, calm tone. Do not physically resist or engage in legal arguments on the street. Let your verbal assertions establish the record.

#### 6. Modern Limitations or Later Modifications
* **Doctrinal Evolution:** UNVERIFIED — requires primary source confirmation.
* **Current Standing:** This case remains binding federal precedent, defining the baseline for modern constitutional litigation under **42 U.S.C. § 1983** and the admissibility of evidence under the **Exclusionary Rule**.

**Verified Majority Quote:**
> "Warrantless searches are per se unreasonable, subject only to a few specifically established and well-delineated exceptions." — Arizona v. Gant, 556 U.S. at 338

---

### Berkemer v. McCarty, 468 U.S. 420 (1984)

#### 1. Core Constitutional Question
* **Amendment Implicated:** **Fifth Amendment**
* **Challenged Authority:** Limits of police authority during warrantless searches, detentions, or interrogations.
* **Legal Standard Evaluated:** The Court evaluated whether the specific law enforcement action met the constitutional threshold required by the **Fifth Amendment**.

**Constitutional Question:**
> Does the rule of Miranda v. Arizona apply to the custodial interrogation of a suspect accused of a misdemeanor traffic offense? Does the roadside questioning of a motorist detained pursuant to a routine traffic stop constitute custodial interrogation for the purposes of the Miranda rule?

#### 2. Fact Pattern
An Ohio State Highway Patrol Trooper observed Richard McCarty's car weaving and pulled him over. After McCarty failed a field sobriety test, the officer determined he would be charged with a traffic offense and was not free to leave, though this was not communicated to McCarty. McCarty admitted to consuming alcohol and marijuana. He was then formally arrested and taken to the county jail, where he again made incriminating statements after a breathalyzer test showed no alcohol. At no point was McCarty given Miranda warnings. He was charged with operating a vehicle under the influence, and his motion to exclude the statements was denied by the trial court, leading to his conviction.

#### 3. Supreme Court Holding
* **Vote Margin:** **Vote 9-0**
* **Majority Author:** **Justice Thurgood Marshall**
* **Ruling Summary:** Miranda warnings must be given to all individuals prior to custodial interrogation, regardless of the nature or severity of the offense. However, the roadside questioning of a motorist detained during a routine traffic stop does not constitute 'custodial interrogation' for Miranda purposes unless the motorist is subjected to restraints comparable to a formal arrest.

**Key Constitutional Test & Doctrinal Rule:**
The Court established that Miranda warnings are required for custodial interrogations regardless of the severity of the offense, rejecting a misdemeanor exception. It also clarified that a routine traffic stop does not, by itself, constitute 'custodial interrogation' for Miranda purposes, but if a motorist is subjected to restraints comparable to a formal arrest, Miranda warnings become necessary.

**Key Concurrences or Dissents:**
Justice John Paul Stevens (concur): Argued that the majority should have limited its decision to the question presented in Berkemer’s petition for certiorari, specifically whether Miranda warnings are required for misdemeanor traffic offenses, rather than addressing the broader issue of roadside questioning.

#### 4. Operational Constitutional Principle
Based on **Berkemer v. McCarty, 468 U.S. 420 (1984)**, the operational boundaries are defined as follows:
* **What Government CAN Legally Do:** Law enforcement is permitted to act within the specific standard established (e.g., order drivers/passengers out of a vehicle as a de minimis safety measure, conduct a brief patdown if reasonable suspicion of being armed and dangerous exists).
* **What Government CANNOT Legally Do:** Law enforcement cannot exceed the temporal or spatial scope of the stop (e.g., prolong a traffic stop for a K-9 sniff without independent reasonable suspicion, conduct a full search under the guise of a Terry patdown).
* **Required Threshold:** The specific constitutional threshold (e.g., **Reasonable Articulable Suspicion**, **Probable Cause**, or **Explicit Invocation**) must be established before government authority can be lawfully exercised.

#### 5. Sovereign Shield Application
Under the **Sovereign Shield** framework, citizens must apply this case law calmly and non-confrontationally:
* **Encounter Protocol:** If stopped or questioned, immediately establish your status by asking, *"Am I free to leave?"* or *"Am I being detained?"*
* **Assertion of Rights:** If the officer asks questions, state clearly and unambiguously: *"I am invoking my right to remain silent."*
* **Consent Refusal:** If asked for permission to search, state: *"I do not consent to any searches."* This preserves your right to challenge any subsequent search under the **Exclusionary Rule**.
* **Calm Demeanor:** Maintain a polite, calm tone. Do not physically resist or engage in legal arguments on the street. Let your verbal assertions establish the record.

#### 6. Modern Limitations or Later Modifications
* **Doctrinal Evolution:** UNVERIFIED — requires primary source confirmation.
* **Current Standing:** This case remains binding federal precedent, defining the baseline for modern constitutional litigation under **42 U.S.C. § 1983** and the admissibility of evidence under the **Exclusionary Rule**.

**Verified Majority Quote:**
> "A policeman's unarticulated plan has no bearing on the question whether a suspect was 'in custody' at a particular time; the only relevant inquiry is how a reasonable man in the suspect's position would have understood his situation." — Berkemer v. McCarty, 468 U.S. at 442

---

### Knowles v. Iowa, 525 U.S. 113 (1998)

#### 1. Core Constitutional Question
* **Amendment Implicated:** **Fourth Amendment**
* **Challenged Authority:** Limits of police authority during warrantless searches, detentions, or interrogations.
* **Legal Standard Evaluated:** The Court evaluated whether the specific law enforcement action met the constitutional threshold required by the **Fourth Amendment**.

**Constitutional Question:**
> Can a search of a stopped vehicle that occurs prior to the driver's arrest be sustained under the "search incident to arrest" exception that permits officers to search stopped vehicles without first obtaining a search warrant?

#### 2. Fact Pattern
After stopping him for speeding, an Iowa police officer issued Patrick Knowles a citation and conducted a full search of his car without probable cause or Knowles' consent. When his search turned up a "pot pipe" and some marijuana, the officer arrested Knowles on state drug charges. Knowles challenged these on grounds that because he was not arrested at any time prior to the search, the search was unconstitutional. On appeal from consecutive adverse rulings in lower courts, the Supreme Court granted Knowles certiorari.

#### 3. Supreme Court Holding
* **Vote Margin:** **Vote 9-0**
* **Majority Author:** **Chief Justice William H. Rehnquist**
* **Ruling Summary:** A full search of an automobile incident to a traffic citation is unconstitutional under the Fourth Amendment.

**Key Constitutional Test & Doctrinal Rule:**
The Court clarified that the "search incident to arrest" exception to the Fourth Amendment's warrant requirement does not authorize a full search of a vehicle when a driver is issued a citation rather than arrested. The justification for a search incident to arrest is officer safety and the preservation of evidence, neither of which is present when only a citation is issued. Therefore, a search incident to a traffic citation is unconstitutional.

**Key Concurrences or Dissents:**
None

#### 4. Operational Constitutional Principle
Based on **Knowles v. Iowa, 525 U.S. 113 (1998)**, the operational boundaries are defined as follows:
* **What Government CAN Legally Do:** Law enforcement is permitted to act within the specific standard established (e.g., order drivers/passengers out of a vehicle as a de minimis safety measure, conduct a brief patdown if reasonable suspicion of being armed and dangerous exists).
* **What Government CANNOT Legally Do:** Law enforcement cannot exceed the temporal or spatial scope of the stop (e.g., prolong a traffic stop for a K-9 sniff without independent reasonable suspicion, conduct a full search under the guise of a Terry patdown).
* **Required Threshold:** The specific constitutional threshold (e.g., **Reasonable Articulable Suspicion**, **Probable Cause**, or **Explicit Invocation**) must be established before government authority can be lawfully exercised.

#### 5. Sovereign Shield Application
Under the **Sovereign Shield** framework, citizens must apply this case law calmly and non-confrontationally:
* **Encounter Protocol:** If stopped or questioned, immediately establish your status by asking, *"Am I free to leave?"* or *"Am I being detained?"*
* **Assertion of Rights:** If the officer asks questions, state clearly and unambiguously: *"I am invoking my right to remain silent."*
* **Consent Refusal:** If asked for permission to search, state: *"I do not consent to any searches."* This preserves your right to challenge any subsequent search under the **Exclusionary Rule**.
* **Calm Demeanor:** Maintain a polite, calm tone. Do not physically resist or engage in legal arguments on the street. Let your verbal assertions establish the record.

#### 6. Modern Limitations or Later Modifications
* **Doctrinal Evolution:** UNVERIFIED — requires primary source confirmation.
* **Current Standing:** This case remains binding federal precedent, defining the baseline for modern constitutional litigation under **42 U.S.C. § 1983** and the admissibility of evidence under the **Exclusionary Rule**.

**Verified Majority Quote:**
> "The search incident to citation is not justified by the need to remove weapons or to prevent the destruction of evidence." — Knowles v. Iowa, 525 U.S. at 118

---

### United States v. Leon, 468 U.S. 897 (1984)

#### 1. Core Constitutional Question
* **Amendment Implicated:** **Fourth Amendment**
* **Challenged Authority:** Limits of police authority during warrantless searches, detentions, or interrogations.
* **Legal Standard Evaluated:** The Court evaluated whether the specific law enforcement action met the constitutional threshold required by the **Fourth Amendment**.

**Constitutional Question:**
> Should the Fourth Amendment exclusionary rule be modified so as not to bar the use in the prosecution's case in chief of evidence obtained by officers acting in reasonable reliance on a search warrant issued by a detached and neutral magistrate but ultimately found to be unsupported by probable cause?

#### 2. Fact Pattern
Burbank police initiated a drug-trafficking investigation based on an anonymous informant's tip. Officers obtained a search warrant for three residences and automobiles, which was reviewed by deputy district attorneys and issued by a state court judge. Searches yielded large quantities of drugs, leading to federal drug indictments. The District Court partially granted motions to suppress evidence, finding the affidavit insufficient for probable cause, despite the officer's good faith. The Court of Appeals affirmed, refusing to recognize a good faith exception.

#### 3. Supreme Court Holding
* **Vote Margin:** **Vote 6-3**
* **Majority Author:** **Justice White**
* **Ruling Summary:** The Fourth Amendment exclusionary rule should not be applied to bar the use in the prosecution's case in chief of evidence obtained by officers acting in reasonable reliance on a search warrant issued by a detached and neutral magistrate but ultimately found to be invalid.

**Key Constitutional Test & Doctrinal Rule:**
The Court established the 'good faith exception' to the exclusionary rule. This doctrine permits the introduction of evidence obtained by officers who acted in objectively reasonable reliance on a search warrant issued by a neutral magistrate, even if the warrant is later found to be invalid. The exception is based on the premise that the exclusionary rule's primary purpose is to deter police misconduct, and this purpose is not served when officers act in good faith.

**Key Concurrences or Dissents:**
Blackmun (concur): Emphasized that the good faith exception was a logical extension of the exclusionary rule's deterrent purpose, not a fundamental shift. Brennan (dissent): Argued that the good faith exception eviscerated the Fourth Amendment's protection against unreasonable searches and seizures, as it removed the incentive for police to ensure warrants are properly issued. Stevens (dissent): Focused on the judicial integrity aspect, arguing that courts should not sanction unconstitutional police conduct by admitting illegally obtained evidence.

#### 4. Operational Constitutional Principle
Based on **United States v. Leon, 468 U.S. 897 (1984)**, the operational boundaries are defined as follows:
* **What Government CAN Legally Do:** Law enforcement is permitted to act within the specific standard established (e.g., order drivers/passengers out of a vehicle as a de minimis safety measure, conduct a brief patdown if reasonable suspicion of being armed and dangerous exists).
* **What Government CANNOT Legally Do:** Law enforcement cannot exceed the temporal or spatial scope of the stop (e.g., prolong a traffic stop for a K-9 sniff without independent reasonable suspicion, conduct a full search under the guise of a Terry patdown).
* **Required Threshold:** The specific constitutional threshold (e.g., **Reasonable Articulable Suspicion**, **Probable Cause**, or **Explicit Invocation**) must be established before government authority can be lawfully exercised.

#### 5. Sovereign Shield Application
Under the **Sovereign Shield** framework, citizens must apply this case law calmly and non-confrontationally:
* **Encounter Protocol:** If stopped or questioned, immediately establish your status by asking, *"Am I free to leave?"* or *"Am I being detained?"*
* **Assertion of Rights:** If the officer asks questions, state clearly and unambiguously: *"I am invoking my right to remain silent."*
* **Consent Refusal:** If asked for permission to search, state: *"I do not consent to any searches."* This preserves your right to challenge any subsequent search under the **Exclusionary Rule**.
* **Calm Demeanor:** Maintain a polite, calm tone. Do not physically resist or engage in legal arguments on the street. Let your verbal assertions establish the record.

#### 6. Modern Limitations or Later Modifications
* **Doctrinal Evolution:** UNVERIFIED — requires primary source confirmation.
* **Current Standing:** This case remains binding federal precedent, defining the baseline for modern constitutional litigation under **42 U.S.C. § 1983** and the admissibility of evidence under the **Exclusionary Rule**.

**Verified Majority Quote:**
> "If exclusion of evidence obtained pursuant to a subsequently invalidated warrant is to have any deterrent effect, that effect must be achieved by altering the behavior of judicial officers rather than of law enforcement agents." — United States v. Leon, 468 U.S. at 916-92.

---


### Operational Analysis: Radar, Pacing, and Consent Traps

To survive a pretextual traffic stop legally and procedurally, you must understand the technical and tactical methods deployed by officers and how to defeat them in court:

#### 1. Speed Measurement & Calibration Challenges
If you are stopped for speeding, the officer's evidence is typically based on one of three methods:
* **Radar / LIDAR:** Radio or laser-based speed detection. To defeat this evidence, your attorney must demand the officer's training certificates, the device's daily calibration logs (which must be performed before and after the shift), and the manufacturer's certification records. If the device has not been calibrated in accordance with strict state guidelines, the evidence is inadmissible.
* **Pacing:** The officer follows your vehicle at a constant distance for a specified duration while monitoring their own speedometer. Pacing requires extensive training and a certified patrol car speedometer. Your defense must challenge the officer's line of sight, traffic conditions, and the calibration history of the patrol vehicle's speedometer.
* **Visual Estimation:** In some jurisdictions, officers are permitted to testify that they "visually estimated" your speed. This is highly subjective and easily challenged on cross-examination by questioning the officer's depth perception, weather conditions, and lack of objective scientific measurement.

#### 2. The Consent Trap
The most dangerous moment of a traffic stop occurs when the officer transition from the traffic investigation to a criminal search. This is almost always executed via a "consent trap." The officer will return your license, issue a warning or ticket, and say: *"Alright, you're free to go. By the way, you don't have anything illegal in the car, do you? You don't mind if I take a quick look inside, just to be safe?"*

If you say *"Go ahead"* or *"I guess not,"* you have fell into the trap. You have granted **voluntary consent**, which completely waives your Fourth Amendment warrant requirement. The correct, unshakeable response is:
> *"Officer, I do not consent to any searches of my vehicle or my person."*

If the officer claims they smell marijuana or have other probable cause, do not physically resist. State clearly:
> *"I am not consenting to this search, but I will comply with your physical commands under protest. I am preserving my constitutional rights."*

---

## IX. DIGITAL PRIVACY & MODERN SEARCHES

We live in a digital panopticon. Modern smartphones, GPS trackers, cloud storage systems, and vehicle telemetry units contain a comprehensive, highly intimate chronicle of our personal lives, physical movements, and communications. As technology has evolved, the Supreme Court has been forced to adapt traditional Fourth Amendment principles to the digital age, establishing robust protections for personal data. This section outlines the modern limits of government authority regarding digital searches, location tracking, and vehicle telemetry.

### The Digital Boundary: Phones and Location Data
For decades, the "search incident to arrest" exception allowed police to search any physical item found on an arrestee's person (e.g., wallets, address books, cigarette packs). However, in the landmark case **Riley v. California**, the Supreme Court drew a firm line at the digital boundary, ruling that a cell phone is fundamentally different from physical property and cannot be searched without a warrant.

### Core Case Law Matrix (Digital Privacy Layer)

### Riley v. California, 573 U.S. 373 (2014)

#### 1. Core Constitutional Question
* **Amendment Implicated:** **Fourth Amendment**
* **Challenged Authority:** Limits of police authority during warrantless searches, detentions, or interrogations.
* **Legal Standard Evaluated:** The Court evaluated whether the specific law enforcement action met the constitutional threshold required by the **Fourth Amendment**.

**Constitutional Question:**
> Was the evidence admitted at trial from Riley's cell phone discovered through a search that violated his Fourth Amendment right to be free from unreasonable searches?

#### 2. Fact Pattern
David Leon Riley, a gang member, was involved in a shooting. Later, he was stopped for expired license tags and arrested for driving with a suspended license. During an inventory search of his impounded car, police found two guns. Riley's cell phone was then searched by a gang unit detective, who found gang-related videos and photographs. This evidence linked Riley to the earlier shooting, leading to his conviction on multiple charges. Riley's motion to suppress the cell phone evidence was denied, and the California Court of Appeal affirmed the conviction.

#### 3. Supreme Court Holding
* **Vote Margin:** **Vote 9-0**
* **Majority Author:** **Chief Justice John G. Roberts, Jr.**
* **Ruling Summary:** The warrantless search of a cell phone incident to arrest is unconstitutional under the Fourth Amendment.

**Key Constitutional Test & Doctrinal Rule:**
The search incident to arrest exception to the Fourth Amendment's warrant requirement does not apply to digital data on cell phones. The Court distinguished cell phones from physical items, emphasizing the vast amount of private information they contain and the minimal threat they pose to officer safety or evidence destruction, especially with modern technological safeguards.

**Key Concurrences or Dissents:**
Justice Samuel A. Alito, Jr. (concur in part and concur in judgment): expressed doubt that the warrantless search exception following an arrest exists solely for officer safety and preserving evidence, but agreed with the majority's conclusion given privacy interests. Suggested legislative action to define reasonable search distinctions for phone data.

#### 4. Operational Constitutional Principle
Based on **Riley v. California, 573 U.S. 373 (2014)**, the operational boundaries are defined as follows:
* **What Government CAN Legally Do:** Law enforcement is permitted to act within the specific standard established (e.g., order drivers/passengers out of a vehicle as a de minimis safety measure, conduct a brief patdown if reasonable suspicion of being armed and dangerous exists).
* **What Government CANNOT Legally Do:** Law enforcement cannot exceed the temporal or spatial scope of the stop (e.g., prolong a traffic stop for a K-9 sniff without independent reasonable suspicion, conduct a full search under the guise of a Terry patdown).
* **Required Threshold:** The specific constitutional threshold (e.g., **Reasonable Articulable Suspicion**, **Probable Cause**, or **Explicit Invocation**) must be established before government authority can be lawfully exercised.

#### 5. Sovereign Shield Application
Under the **Sovereign Shield** framework, citizens must apply this case law calmly and non-confrontationally:
* **Encounter Protocol:** If stopped or questioned, immediately establish your status by asking, *"Am I free to leave?"* or *"Am I being detained?"*
* **Assertion of Rights:** If the officer asks questions, state clearly and unambiguously: *"I am invoking my right to remain silent."*
* **Consent Refusal:** If asked for permission to search, state: *"I do not consent to any searches."* This preserves your right to challenge any subsequent search under the **Exclusionary Rule**.
* **Calm Demeanor:** Maintain a polite, calm tone. Do not physically resist or engage in legal arguments on the street. Let your verbal assertions establish the record.

#### 6. Modern Limitations or Later Modifications
* **Doctrinal Evolution:** UNVERIFIED — requires primary source confirmation.
* **Current Standing:** This case remains binding federal precedent, defining the baseline for modern constitutional litigation under **42 U.S.C. § 1983** and the admissibility of evidence under the **Exclusionary Rule**.

**Verified Majority Quote:**
> "Our answer to the question of what police must do before searching a cell phone seized incident to an arrest is accordingly simple—get a warrant." — Riley v. California, 573 U.S. at 403

---

### Carpenter v. United States, 585 U.S. 296 (2018)

#### 1. Core Constitutional Question
* **Amendment Implicated:** **Fourth Amendment**
* **Challenged Authority:** Limits of police authority during warrantless searches, detentions, or interrogations.
* **Legal Standard Evaluated:** The Court evaluated whether the specific law enforcement action met the constitutional threshold required by the **Fourth Amendment**.

**Constitutional Question:**
> Does the warrantless search and seizure of cell phone records, which include the location and movements of cell phone users, violate the Fourth Amendment?

#### 2. Fact Pattern
In April 2011, police arrested men suspected of armed robberies. One suspect confessed and provided cell phone numbers of accomplices, including Timothy Carpenter. The FBI obtained court orders under the Stored Communications Act to acquire Carpenter's cell-site location information (CSLI) for 127 days, which showed his proximity to robbery locations. Carpenter moved to suppress this evidence, arguing it was a warrantless search violating the Fourth Amendment. The district court denied the motion, and the Sixth Circuit affirmed, holding Carpenter had no reasonable expectation of privacy in CSLI shared with a third party. The Supreme Court granted certiorari.

#### 3. Supreme Court Holding
* **Vote Margin:** **Vote 5-4**
* **Majority Author:** **Chief Justice John G. Roberts, Jr.**
* **Ruling Summary:** The government's acquisition of historical cell-site records constitutes a Fourth Amendment search, and generally requires a warrant supported by probable cause.

**Key Constitutional Test & Doctrinal Rule:**
The Court established that individuals have a legitimate expectation of privacy in the comprehensive historical cell-site location information (CSLI) collected by wireless carriers. This information, which provides a detailed chronicle of a person's physical movements, is not subject to the third-party doctrine. Therefore, the government generally needs a warrant supported by probable cause to access such records, unless exigent circumstances apply.

**Key Concurrences or Dissents:**
Kennedy (dissent): Joined by Thomas and Alito, argued that the majority's decision departed from established Fourth Amendment jurisprudence, particularly the third-party doctrine, and created uncertainty. Thomas (dissent): Argued that the Fourth Amendment protects property interests, not privacy interests, and that CSLI is not Carpenter's property. Alito (dissent): Joined by Thomas, criticized the majority for creating a new, vague standard for Fourth Amendment searches and for failing to provide clear guidance for law enforcement. Gorsuch (dissent): Argued that the case should have been decided based on property rights under the Fourth Amendment, rather than privacy expectations, and that the government's actions constituted a trespass.

#### 4. Operational Constitutional Principle
Based on **Carpenter v. United States, 585 U.S. 296 (2018)**, the operational boundaries are defined as follows:
* **What Government CAN Legally Do:** Law enforcement is permitted to act within the specific standard established (e.g., order drivers/passengers out of a vehicle as a de minimis safety measure, conduct a brief patdown if reasonable suspicion of being armed and dangerous exists).
* **What Government CANNOT Legally Do:** Law enforcement cannot exceed the temporal or spatial scope of the stop (e.g., prolong a traffic stop for a K-9 sniff without independent reasonable suspicion, conduct a full search under the guise of a Terry patdown).
* **Required Threshold:** The specific constitutional threshold (e.g., **Reasonable Articulable Suspicion**, **Probable Cause**, or **Explicit Invocation**) must be established before government authority can be lawfully exercised.

#### 5. Sovereign Shield Application
Under the **Sovereign Shield** framework, citizens must apply this case law calmly and non-confrontationally:
* **Encounter Protocol:** If stopped or questioned, immediately establish your status by asking, *"Am I free to leave?"* or *"Am I being detained?"*
* **Assertion of Rights:** If the officer asks questions, state clearly and unambiguously: *"I am invoking my right to remain silent."*
* **Consent Refusal:** If asked for permission to search, state: *"I do not consent to any searches."* This preserves your right to challenge any subsequent search under the **Exclusionary Rule**.
* **Calm Demeanor:** Maintain a polite, calm tone. Do not physically resist or engage in legal arguments on the street. Let your verbal assertions establish the record.

#### 6. Modern Limitations or Later Modifications
* **Doctrinal Evolution:** UNVERIFIED — requires primary source confirmation.
* **Current Standing:** This case remains binding federal precedent, defining the baseline for modern constitutional litigation under **42 U.S.C. § 1983** and the admissibility of evidence under the **Exclusionary Rule**.

**Verified Majority Quote:**
> "The Government’s acquisition of the cell-site records here was a search under that Amendment." — Carpenter v. United States, 585 U.S. at 303

---


### Modern Technical Realities: Telemetry, GPS, and Cloud Storage
As citizens navigate the modern digital landscape, they must understand how constitutional protections apply to emerging technologies:
1. **Vehicle Telemetry & Black Boxes:** Modern vehicles are equipped with Event Data Recorders (EDRs) and infotainment systems that continuously log speed, braking, seatbelt usage, GPS coordinates, and even connected smartphone contacts. Law enforcement cannot extract this data without a search warrant supported by probable cause, as a vehicle's digital systems enjoy a high expectation of privacy under **Riley**.
2. **GPS Tracking Devices:** Under **United States v. Jones** (2012), the physical attachment of a GPS tracking device to a vehicle by law enforcement constitutes a physical trespass on an "effect," which is a Fourth Amendment search requiring a warrant. Police cannot secretly track your vehicle's movements on public streets indefinitely without judicial authorization.
3. **Cloud Storage & Encryption:** Data stored in the cloud (e.g., iCloud, Google Drive) is protected by the Fourth Amendment, requiring a warrant to compel the service provider to disclose your files. Furthermore, you have an absolute right to encrypt your devices. Law enforcement cannot compel you to disclose your passcode or biometric key (FaceID/TouchID) to unlock a phone, as doing so directly implicates your Fifth Amendment privilege against self-incrimination.

---

## X. REAL-WORLD COURTROOM PROCESS

Constitutional rights are not self-enforcing. They do not magically manifest at the roadside to stop an officer from conducting an illegal search or making an unlawful arrest. Instead, rights are **enforced retroactively** through the complex, rigid, and highly procedural machinery of the courtroom. If you do not understand the rules of criminal procedure, your constitutional assertions are useless. This section demystifies the chronological courtroom process, explaining how rights are converted into dismissals, suppression of evidence, and legal victories.

### 1. The Arraignment & Bail Hearing
The courtroom process begins at the arraignment, which is your first formal appearance before a judge:
* **The Charges:** The judge will formally read the criminal complaint or indictment filed against you by the prosecutor.
* **The Plea:** You will enter a formal plea of "Not Guilty." Never plead guilty or no contest at an arraignment, regardless of the evidence.
* **Bail & Release Conditions:** The court will determine whether to release you on your own recognizance (OR) or set a financial bail. Your attorney will argue for release based on your ties to the community, lack of flight risk, and clean record.

### 2. The Discovery Phase
Discovery is the engine of your defense. Under **Brady v. Maryland** and statutory rules of criminal procedure, the prosecution is legally required to turn over all evidence in their possession to your defense counsel:
* **What You Must Demand:** Your attorney must file a comprehensive discovery motion demanding all police reports, CAD logs, 911 audio recordings, radio transmissions, bodycam footage, dashcam footage, officer training records, and calibration logs for any speed detection or breathalyzer devices.
* **Analyzing the Discrepancies:** Your defense team will meticulously compare the written police reports against the raw bodycam footage and dispatch logs. Any discrepancies in timelines, physical actions, or officer statements constitute critical **Giglio** impeachment material.

### 3. The Suppression Hearing (The Exclusionary Rule in Action)
The suppression hearing is the ultimate constitutional battleground. This is where your **Sovereign Shield** is formally deployed to destroy the prosecution's case:
* **The Motion to Suppress:** Your attorney will file a formal motion under **1538.5** (in California) or federal rules, arguing that the police obtained evidence in violation of your Fourth, Fifth, or Fourteenth Amendment rights.
* **The Burden of Proof:** In a warrantless search or seizure, the prosecution bears the burden of proving by a preponderance of the evidence that the police acted within a recognized exception to the warrant requirement (e.g., consent, plain view, automobile exception).
* **The Outcome:** If the judge rules that the initial stop lacked reasonable suspicion, or that the subsequent search lacked probable cause, the **Exclusionary Rule** is invoked. All evidence seized during that unlawful encounter is suppressed as "Fruit of the Poisonous Tree." Without the evidence, the prosecution is almost always forced to dismiss all charges.

### 4. Plea Negotiations & Trial
* **Plea Bargaining:** If the motion to suppress is denied, the case may proceed to plea negotiations. Prosecutors, aware of the risks of trial and the credibility vulnerabilities of their officers, may offer significantly reduced charges or probation.
* **The Trial:** If no agreement is reached, the case proceeds to trial, where the prosecution must prove your guilt **Beyond a Reasonable Doubt** to a unanimous jury. Your attorney will cross-examine the officers, deploying the **Giglio** impeachment material to destroy their credibility on the witness stand.

---

## XI. CALIFORNIA-SPECIFIC OPERATIONS LAYER

While federal constitutional law establishes the baseline of civil rights across the United States, individual states are permitted to enact statutes and constitutional provisions that provide broader protections for their citizens. Because you are operating within the State of California, you must understand the highly specific state-level statutes, vehicle codes, and peace officer disclosure laws that govern your daily operations. Federal literacy alone is incomplete without this local operational layer.

### 1. California Stop-and-Identify Realities
* **No Stop-and-Identify Statute:** California **does not** have a stop-and-identify statute. Unlike states governed strictly by Hiibel, a pedestrian detained in California under a Terry stop is **not** legally obligated to provide identification or state their name, unless they are being arrested or are operating a motor vehicle.
* **Refusal to Identify:** Refusing to provide identification to a California police officer during a temporary detention does not constitute a violation of **Penal Code § 148** (resisting, delaying, or obstructing an officer), as long as the refusal is passive and does not involve physical resistance or active obstruction.

### 2. California Recording Laws
* **Two-Party Consent Rule:** California is a "two-party consent" state under **Penal Code § 632**, meaning it is generally a crime to record a confidential communication without the consent of all parties.
* **The Police Exception:** This rule **does not** apply to recording police officers performing their duties in public spaces. A conversation with a police officer during a traffic stop or street encounter is objectively **not confidential**. You have an absolute right to record officers openly, and doing so does not violate California wiretapping laws.

### 3. California Vehicle Search & Firearm Transport Law
* **The Smell of Marijuana:** Following the passage of Proposition 64, the smell of burnt or raw marijuana, by itself, **no longer** establishes probable cause to search a vehicle in California (**Health & Safety Code § 11362.1**). Officers must observe additional indicators of criminal activity (e.g., driving under the influence, open containers of cannabis, or illicit transport of commercial quantities) to justify a warrantless vehicle search.
* **Firearm Transport:** Under California law, handguns transported in a vehicle must be **unloaded** and secured in a **locked container** (such as the trunk or a locked utility box). The glove compartment or utility console does not qualify as a locked container. Long guns must be transported unloaded, but do not require a locked container.

### 4. California Peace Officer Disclosure Laws (SB 1421 & SB 2)
California has some of the most robust officer accountability and transparency laws in the nation, providing powerful tools for the defense:
* **SB 1421 (Officer Records):** This statute makes critical officer disciplinary records subject to public disclosure under the California Public Records Act. This includes records related to officer-involved shootings, use of force causing great bodily injury, and sustained findings of **officer dishonesty** (lying in reports, fabricating evidence) or sexual assault.
* **SB 2 (Decertification):** Enacted to prevent "wandering officers" (those fired for misconduct who simply get hired by another department), SB 2 establishes a statewide system to permanently decertify officers who engage in serious misconduct, including bias, dishonesty, or excessive force.

---

## XII. CONSTITUTIONAL DOCTRINE REFERENCE TABLES

This section consolidates critical constitutional thresholds, search exceptions, and citizen rights into structured, institutional-grade reference tables.

### Table A: Levels of Suspicion

| Standard | Legal Definition | Required Evidence | Relevant Cases | Permitted Police Actions |
| :--- | :--- | :--- | :--- | :--- |
| **No Suspicion** | Voluntary contact with no restriction on liberty. | None. | **Katz v. United States** [14] | Approach, ask questions, request ID, ask for consent to search. |
| **Mere Suspicion** | A subjective hunch, intuition, or gut feeling. | No objective facts required. | **Delaware v. Prouse** [6] | Observe from public spaces, follow, run license plates. Cannot detain. |
| **Reasonable Articulable Suspicion (RAS)** | Specific, articulable facts that would lead a reasonable officer to suspect crime is afoot. | Objective, observable facts (e.g., casing a store, matching a suspect description). | **Terry v. Ohio** [7], **Hiibel v. Nevada** [8] | Initiate temporary investigatory detention (Terry stop), conduct a weapons patdown (Terry frisk) if armed and dangerous. |
| **Probable Cause** | A fair probability that contraband or evidence of a crime will be found, or that a crime has been committed. | Strong, objective evidence (e.g., smell of marijuana, visible contraband, admissions, reliable tips). | **Brinegar v. United States** [4], **Carroll v. United States** [5] | Conduct warrantless vehicle search (automobile exception), make a formal arrest, obtain search/arrest warrants. |
| **Beyond a Reasonable Doubt** | The standard of proof required to convict a defendant in a criminal trial. | Proof that leaves no reasonable doubt of guilt. | N/A (Trial Standard) | Obtain a criminal conviction and sentence. |

---

### Table B: Search Categories and Warrant Exceptions

| Search Type | Warrant Required? | Exceptions | Governing Cases | Operational Rule |
| :--- | :--- | :--- | :--- | :--- |
| **Consent Search** | **No** | Explicit, voluntary consent given by an authorized individual. | **Schneckloth v. Bustamonte** | Search is limited strictly to the scope of consent given. Consent can be withdrawn at any time. |
| **Automobile Exception** | **No** | Probable cause to believe the vehicle contains contraband or evidence. | **Carroll v. United States** [5], **United States v. Ross** | May search the entire vehicle and any containers that could reasonably hold the object of the search. |
| **Terry Frisk** | **No** | Reasonable suspicion that the suspect is armed and dangerous. | **Terry v. Ohio** [7], **Arizona v. Johnson** [11] | Limited strictly to a patdown of outer clothing for weapons. Cannot search pockets unless contraband is immediately apparent by feel. |
| **Search Incident to Arrest** | **No** | Lawful custodial arrest. | **Chimel v. California**, **Arizona v. Gant** [112] | May search the arrestee's person and the immediate "grab area" (wingspan) for weapons or evidence destruction prevention. |
| **Plain View Doctrine** | **No** | Officer is lawfully present, object is in plain view, and its incriminating character is immediately apparent. | **Horton v. California** | May seize evidence without a warrant if all three conditions are met. |
| **Exigent Circumstances** | **No** | Emergency situations (hot pursuit, imminent destruction of evidence, threat to life). | **Kentucky v. King** | Warrantless entry and search permitted strictly to resolve the emergency. |

---

### Table C: Citizen Rights and Recommended Assertions

| Situation | Citizen Rights | Police Authority Limits | Recommended Constitutional Assertion |
| :--- | :--- | :--- | :--- |
| **Voluntary Encounter on the Street** | Right to ignore, decline questioning, and walk away. | Cannot physically block, command compliance, or display weapons. | *"Officer, am I free to leave, or am I being detained?"* |
| **Investigatory Detention (Terry Stop)** | Right to remain silent; right to be free from prolonged detention. | Cannot conduct a full search; cannot transport to station without arrest. | *"I am invoking my right to remain silent. I do not consent to any searches."* |
| **Traffic Stop (Driver)** | Right to refuse vehicle search; right to refuse prolonged detention. | May order driver out of car; cannot prolong stop for K-9 without RAS. | *"I do not consent to any searches. Has the traffic investigation concluded?"* |
| **Traffic Stop (Passenger)** | Right to remain silent; right to refuse identification (unless RAS exists). | May order passenger out of car; cannot frisk without RAS of being armed/dangerous. | *"As a passenger, am I being detained or am I free to go? I do not consent to any searches."* |
| **Formal Arrest & Custody** | Absolute right to counsel; right to remain silent. | Must cease interrogation immediately upon invocation of rights. | *"I am invoking my Fifth Amendment right to remain silent and my right to counsel. I will not answer questions without my attorney."* |

---

## XIII. INSTITUTIONAL AUDIT & DEFENSIVE CHARGEBACK SHIELD

In the high-ticket consulting and sovereign systems industry, maintaining institutional-grade documentation is not merely an academic exercise — it is a critical business asset. This manual serves as a **Defensive Chargeback Shield** and audit-ready proof of execution.

### Audit Readiness Protocol
Every consulting engagement and system installation delivered under the **Prime Pathwy** banner is backed by an unshakeable, legally binding record. In the event of a client dispute, credit card chargeback, or institutional audit, this document provides absolute proof of professional, deeply researched, and customized deliverables that meet the highest standards of execution.

### Legal Disclaimer
> **NOTICE:** The information contained in this reference manual is intended for educational and study purposes only. It does not constitute formal legal advice. For specific legal representation or advice regarding a pending criminal or civil matter, please consult with a licensed, qualified attorney in your jurisdiction.

---

## XIV. PRIMARY SOURCE REFERENCES

1. **Weeks v. United States**, 232 U.S. 383 (1914) — [Oyez Link](https://www.oyez.org/cases/1900-1940/232us383) | [Justia Link](https://supreme.justia.com/cases/federal/us/232/383/)
2. **Mapp v. Ohio**, 367 U.S. 643 (1961) — [Oyez Link](https://www.oyez.org/cases/1960/236) | [Justia Link](https://supreme.justia.com/cases/federal/us/367/643/)
3. **Nardone v. United States**, 308 U.S. 338 (1939) — [Justia Link](https://supreme.justia.com/cases/federal/us/308/338/)
4. **Brinegar v. United States**, 338 U.S. 160 (1949) — [Oyez Link](https://www.oyez.org/cases/1940-1955/338us160) | [Justia Link](https://supreme.justia.com/cases/federal/us/338/160/)
5. **Carroll v. United States**, 267 U.S. 132 (1925) — [Oyez Link](https://www.oyez.org/cases/1900-1940/267us132) | [Justia Link](https://supreme.justia.com/cases/federal/us/267/132/)
6. **Delaware v. Prouse**, 440 U.S. 648 (1979) — [Oyez Link](https://www.oyez.org/cases/1978/77-1571) | [Justia Link](https://supreme.justia.com/cases/federal/us/440/648/)
7. **Terry v. Ohio**, 392 U.S. 1 (1968) — [Oyez Link](https://www.oyez.org/cases/1967/67) | [Justia Link](https://supreme.justia.com/cases/federal/us/392/1/)
8. **Hiibel v. Sixth Judicial District Court of Nevada**, 542 U.S. 177 (2004) — [Oyez Link](https://www.oyez.org/cases/2003/03-5554) | [Justia Link](https://supreme.justia.com/cases/federal/us/542/177/)
9. **Pennsylvania v. Mimms**, 434 U.S. 106 (1977) — [Oyez Link](https://www.oyez.org/cases/1977/76-1830) | [Justia Link](https://supreme.justia.com/cases/federal/us/434/106/)
10. **Maryland v. Wilson**, 519 U.S. 408 (1997) — [Oyez Link](https://www.oyez.org/cases/1996/95-1268) | [Justia Link](https://supreme.justia.com/cases/federal/us/519/408/)
11. **Arizona v. Johnson**, 555 U.S. 323 (2009) — [Oyez Link](https://www.oyez.org/cases/2008/07-1122) | [Justia Link](https://supreme.justia.com/cases/federal/us/555/323/)
12. **Rodriguez v. United States**, 575 U.S. 348 (2015) — [Oyez Link](https://www.oyez.org/cases/2014/13-1175) | [Justia Link](https://supreme.justia.com/cases/federal/us/575/348/)
13. **Illinois v. Caballes**, 543 U.S. 405 (2005) — [Oyez Link](https://www.oyez.org/cases/2004/03-923) | [Justia Link](https://supreme.justia.com/cases/federal/us/543/405/)
14. **Katz v. United States**, 389 U.S. 347 (1967) — [Oyez Link](https://www.oyez.org/cases/1967/116) | [Justia Link](https://supreme.justia.com/cases/federal/us/389/347/)
15. **Florida v. Jardines**, 569 U.S. 1 (2013) — [Oyez Link](https://www.oyez.org/cases/2012/11-564) | [Justia Link](https://supreme.justia.com/cases/federal/us/569/1/)
16. **Miranda v. Arizona**, 384 U.S. 436 (1966) — [Oyez Link](https://www.oyez.org/cases/1965/759) | [Justia Link](https://supreme.justia.com/cases/federal/us/384/436/)
17. **Berghuis v. Thompkins**, 560 U.S. 370 (2010) — [Oyez Link](https://www.oyez.org/cases/2009/08-1470) | [Justia Link](https://supreme.justia.com/cases/federal/us/560/370/)
18. **Salinas v. Texas**, 570 U.S. 178 (2013) — [Oyez Link](https://www.oyez.org/cases/2012/12-246) | [Justia Link](https://supreme.justia.com/cases/federal/us/570/178/)
19. **Brady v. Maryland**, 373 U.S. 83 (1963) — [Oyez Link](https://www.oyez.org/cases/1962/490) | [Justia Link](https://supreme.justia.com/cases/federal/us/373/83/)
20. **Giglio v. United States**, 405 U.S. 150 (1972) — [Oyez Link](https://www.oyez.org/cases/1971/70-29) | [Justia Link](https://supreme.justia.com/cases/federal/us/405/150/)
21. **Napue v. Illinois**, 360 U.S. 264 (1959) — [Oyez Link](https://www.oyez.org/cases/1958/583) | [Justia Link](https://supreme.justia.com/cases/federal/us/360/264/)
22. **Monell v. Department of Social Services**, 436 U.S. 658 (1978) — [Oyez Link](https://www.oyez.org/cases/1977/75-1914) | [Justia Link](https://supreme.justia.com/cases/federal/us/436/658/)
23. **Graham v. Connor**, 490 U.S. 386 (1989) — [Oyez Link](https://www.oyez.org/cases/1988/87-6571) | [Justia Link](https://supreme.justia.com/cases/federal/us/490/386/)
24. **Tennessee v. Garner**, 471 U.S. 1 (1985) — [Oyez Link](https://www.oyez.org/cases/1984/83-1425) | [Justia Link](https://supreme.justia.com/cases/federal/us/471/1/)
25. **Whren v. United States**, 517 U.S. 806 (1996) — [Oyez Link](https://www.oyez.org/cases/1995/95-5841) | [Justia Link](https://supreme.justia.com/cases/federal/us/517/806/)
26. **Arizona v. Gant**, 556 U.S. 332 (2009) — [Oyez Link](https://www.oyez.org/cases/2008/07-542) | [Justia Link](https://supreme.justia.com/cases/federal/us/556/332/)
27. **Berkemer v. McCarty**, 468 U.S. 420 (1984) — [Oyez Link](https://www.oyez.org/cases/1983/83-710) | [Justia Link](https://supreme.justia.com/cases/federal/us/468/420/)
28. **Knowles v. Iowa**, 525 U.S. 113 (1998) — [Oyez Link](https://www.oyez.org/cases/1998/97-7597) | [Justia Link](https://supreme.justia.com/cases/federal/us/525/113/)
29. **United States v. Leon**, 468 U.S. 897 (1984) — [Oyez Link](https://www.oyez.org/cases/1983/82-1771) | [Justia Link](https://supreme.justia.com/cases/federal/us/468/897/)
30. **Riley v. California**, 573 U.S. 373 (2014) — [Oyez Link](https://www.oyez.org/cases/2013/13-132) | [Justia Link](https://supreme.justia.com/cases/federal/us/573/373/)
31. **Carpenter v. United States**, 585 U.S. 296 (2018) — [Oyez Link](https://www.oyez.org/cases/2017/16-402) | [Justia Link](https://supreme.justia.com/cases/federal/us/585/296/)
